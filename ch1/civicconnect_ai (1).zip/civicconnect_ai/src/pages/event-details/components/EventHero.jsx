import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';

const EventHero = ({ event }) => {
  return (
    <div className="relative w-full h-64 md:h-80 lg:h-96 rounded-lg overflow-hidden mb-6">
      <Image
        src={event?.image}
        alt={event?.title}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
        <div className="flex flex-wrap gap-2 mb-3">
          {event?.tags?.map((tag, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-white/20 backdrop-blur-sm text-white text-xs font-medium rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-2">{event?.title}</h1>
        <div className="flex flex-wrap items-center gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <Icon name="Calendar" size={16} />
            <span>{event?.date}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} />
            <span>{event?.time}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={16} />
            <span>{event?.location}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventHero;