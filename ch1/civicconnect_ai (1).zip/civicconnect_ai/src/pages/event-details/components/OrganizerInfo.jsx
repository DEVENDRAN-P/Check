import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const OrganizerInfo = ({ organizer }) => {
  const [showContact, setShowContact] = useState(false);

  const handleMessage = () => {
    setShowContact(true);
    // Handle messaging logic
  };

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <h2 className="text-xl font-semibold text-card-foreground mb-4">Event Organizer</h2>
      <div className="flex items-start space-x-4">
        <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
          <Image
            src={organizer?.avatar}
            alt={organizer?.name}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <h3 className="font-semibold text-card-foreground">{organizer?.name}</h3>
            {organizer?.verified && (
              <Icon name="BadgeCheck" size={16} className="text-primary" />
            )}
          </div>
          
          <p className="text-text-secondary text-sm mb-2">{organizer?.role}</p>
          <p className="text-text-secondary text-sm mb-3">{organizer?.organization}</p>
          
          <div className="flex items-center space-x-4 text-sm text-text-secondary mb-4">
            <div className="flex items-center space-x-1">
              <Icon name="Calendar" size={14} />
              <span>{organizer?.eventsOrganized} events</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Star" size={14} />
              <span>{organizer?.rating}/5.0</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Users" size={14} />
              <span>{organizer?.followers} followers</span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleMessage}
              iconName="MessageCircle"
              iconPosition="left"
            >
              Message
            </Button>
            <Button
              variant="ghost"
              size="sm"
              iconName="UserPlus"
              iconPosition="left"
            >
              Follow
            </Button>
          </div>
        </div>
      </div>
      {organizer?.bio && (
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-text-secondary text-sm leading-relaxed">{organizer?.bio}</p>
        </div>
      )}
      {organizer?.achievements && (
        <div className="mt-4 pt-4 border-t border-border">
          <h4 className="font-medium text-card-foreground mb-2">Achievements</h4>
          <div className="flex flex-wrap gap-2">
            {organizer?.achievements?.map((achievement, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-success/10 text-success text-xs font-medium rounded-full"
              >
                {achievement}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganizerInfo;