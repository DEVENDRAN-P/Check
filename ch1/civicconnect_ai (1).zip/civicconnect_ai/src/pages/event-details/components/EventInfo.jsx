import React from 'react';
import Icon from '../../../components/AppIcon';

const EventInfo = ({ event }) => {
  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <h2 className="text-xl font-semibold text-card-foreground mb-4">Event Information</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <Icon name="Calendar" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Date & Time</p>
              <p className="text-text-secondary">{event?.date}</p>
              <p className="text-text-secondary">{event?.time}</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Icon name="MapPin" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Location</p>
              <p className="text-text-secondary">{event?.location}</p>
              <p className="text-text-secondary">{event?.address}</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Icon name="Users" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Attendance</p>
              <p className="text-text-secondary">{event?.attendees} attending</p>
              <p className="text-text-secondary">Capacity: {event?.capacity}</p>
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <Icon name="DollarSign" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Cost</p>
              <p className="text-text-secondary">{event?.cost || 'Free'}</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Icon name="Tag" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Category</p>
              <p className="text-text-secondary">{event?.category}</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Icon name="Clock" size={20} className="text-primary mt-1" />
            <div>
              <p className="font-medium text-card-foreground">Duration</p>
              <p className="text-text-secondary">{event?.duration}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventInfo;