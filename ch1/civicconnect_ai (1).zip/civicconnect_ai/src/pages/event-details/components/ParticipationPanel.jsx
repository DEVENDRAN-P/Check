import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ParticipationPanel = ({ event }) => {
  const [rsvpStatus, setRsvpStatus] = useState('none'); // none, attending, waitlist
  const [showWaitlist, setShowWaitlist] = useState(false);

  const handleRSVP = (status) => {
    setRsvpStatus(status);
    // Handle RSVP logic
  };

  const handleWaitlist = () => {
    setShowWaitlist(true);
    setRsvpStatus('waitlist');
    // Handle waitlist logic
  };

  const availableSpots = event?.capacity - event?.attendees;
  const isFullyBooked = availableSpots <= 0;

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft sticky top-20">
      <div className="text-center mb-6">
        <div className="text-3xl font-bold text-primary mb-2">
          {event?.cost || 'Free'}
        </div>
        <p className="text-text-secondary">per person</p>
      </div>
      <div className="space-y-4 mb-6">
        <div className="flex justify-between items-center">
          <span className="text-text-secondary">Attendees</span>
          <span className="font-medium text-card-foreground">
            {event?.attendees}/{event?.capacity}
          </span>
        </div>
        
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${(event?.attendees / event?.capacity) * 100}%` }}
          />
        </div>
        
        <div className="flex justify-between items-center text-sm">
          <span className="text-success">
            {availableSpots > 0 ? `${availableSpots} spots left` : 'Fully booked'}
          </span>
          <span className="text-text-secondary">
            {Math.round((event?.attendees / event?.capacity) * 100)}% full
          </span>
        </div>
      </div>
      {rsvpStatus === 'none' && (
        <div className="space-y-3">
          {!isFullyBooked ? (
            <Button
              variant="default"
              fullWidth
              onClick={() => handleRSVP('attending')}
              iconName="UserPlus"
              iconPosition="left"
            >
              RSVP - I'm Attending
            </Button>
          ) : (
            <Button
              variant="outline"
              fullWidth
              onClick={handleWaitlist}
              iconName="Clock"
              iconPosition="left"
            >
              Join Waitlist
            </Button>
          )}
          
          <Button
            variant="ghost"
            fullWidth
            iconName="Calendar"
            iconPosition="left"
          >
            Add to Calendar
          </Button>
        </div>
      )}
      {rsvpStatus === 'attending' && (
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 text-success mb-3">
            <Icon name="CheckCircle" size={20} />
            <span className="font-medium">You're attending!</span>
          </div>
          <Button
            variant="outline"
            fullWidth
            onClick={() => handleRSVP('none')}
          >
            Cancel RSVP
          </Button>
        </div>
      )}
      {rsvpStatus === 'waitlist' && (
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 text-warning mb-3">
            <Icon name="Clock" size={20} />
            <span className="font-medium">You're on the waitlist</span>
          </div>
          <p className="text-text-secondary text-sm mb-3">
            We'll notify you if a spot opens up
          </p>
          <Button
            variant="outline"
            fullWidth
            onClick={() => setRsvpStatus('none')}
          >
            Leave Waitlist
          </Button>
        </div>
      )}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="icon"
            iconName="Share2"
          />
          <Button
            variant="ghost"
            size="icon"
            iconName="Heart"
          />
          <Button
            variant="ghost"
            size="icon"
            iconName="Bookmark"
          />
        </div>
      </div>
    </div>
  );
};

export default ParticipationPanel;