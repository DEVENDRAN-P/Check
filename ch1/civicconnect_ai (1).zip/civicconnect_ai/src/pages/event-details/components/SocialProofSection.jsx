import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';

const SocialProofSection = ({ attendees, testimonials, mutualConnections }) => {
  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <h2 className="text-xl font-semibold text-card-foreground mb-4">Who's Attending</h2>
      {/* Mutual Connections */}
      {mutualConnections && mutualConnections?.length > 0 && (
        <div className="mb-6">
          <h3 className="font-medium text-card-foreground mb-3">Your Connections</h3>
          <div className="flex items-center space-x-3">
            <div className="flex -space-x-2">
              {mutualConnections?.slice(0, 4)?.map((connection, index) => (
                <div key={index} className="w-8 h-8 rounded-full border-2 border-background overflow-hidden">
                  <Image
                    src={connection?.avatar}
                    alt={connection?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
            <p className="text-text-secondary text-sm">
              {mutualConnections?.length > 4 
                ? `${mutualConnections?.slice(0, 3)?.map(c => c?.name)?.join(', ')} and ${mutualConnections?.length - 3} others`
                : mutualConnections?.map(c => c?.name)?.join(', ')
              } are attending
            </p>
          </div>
        </div>
      )}
      {/* Recent Attendees */}
      <div className="mb-6">
        <h3 className="font-medium text-card-foreground mb-3">Recent RSVPs</h3>
        <div className="space-y-3">
          {attendees?.slice(0, 5)?.map((attendee, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src={attendee?.avatar}
                  alt={attendee?.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <p className="font-medium text-card-foreground text-sm">{attendee?.name}</p>
                <p className="text-text-secondary text-xs">{attendee?.role}</p>
              </div>
              <div className="text-text-secondary text-xs">
                {attendee?.joinedTime}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Testimonials */}
      {testimonials && testimonials?.length > 0 && (
        <div>
          <h3 className="font-medium text-card-foreground mb-3">What People Say</h3>
          <div className="space-y-4">
            {testimonials?.map((testimonial, index) => (
              <div key={index} className="p-4 bg-muted rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="flex text-warning">
                    {[...Array(5)]?.map((_, i) => (
                      <Icon 
                        key={i} 
                        name="Star" 
                        size={12} 
                        className={i < testimonial?.rating ? 'fill-current' : ''} 
                      />
                    ))}
                  </div>
                  <span className="text-text-secondary text-xs">
                    {testimonial?.date}
                  </span>
                </div>
                <p className="text-text-secondary text-sm mb-2">"{testimonial?.comment}"</p>
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden">
                    <Image
                      src={testimonial?.avatar}
                      alt={testimonial?.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-card-foreground text-xs font-medium">
                    {testimonial?.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SocialProofSection;