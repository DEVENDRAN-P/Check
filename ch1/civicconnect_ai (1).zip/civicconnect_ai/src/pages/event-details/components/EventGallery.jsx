import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EventGallery = ({ photos, eventTitle }) => {
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [showAll, setShowAll] = useState(false);

  if (!photos || photos?.length === 0) return null;

  const displayPhotos = showAll ? photos : photos?.slice(0, 6);

  const openLightbox = (photo, index) => {
    setSelectedPhoto({ ...photo, index });
  };

  const closeLightbox = () => {
    setSelectedPhoto(null);
  };

  const navigatePhoto = (direction) => {
    const currentIndex = selectedPhoto?.index;
    const newIndex = direction === 'next' 
      ? (currentIndex + 1) % photos?.length
      : (currentIndex - 1 + photos?.length) % photos?.length;
    
    setSelectedPhoto({ ...photos?.[newIndex], index: newIndex });
  };

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-card-foreground">Event Gallery</h2>
        <span className="text-text-secondary text-sm">{photos?.length} photos</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {displayPhotos?.map((photo, index) => (
          <div
            key={index}
            className="relative aspect-square rounded-lg overflow-hidden cursor-pointer group"
            onClick={() => openLightbox(photo, index)}
          >
            <Image
              src={photo?.url}
              alt={photo?.caption || `${eventTitle} photo ${index + 1}`}
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
              <Icon 
                name="ZoomIn" 
                size={24} 
                className="text-white opacity-0 group-hover:opacity-100 transition-opacity" 
              />
            </div>
            {photo?.caption && (
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                <p className="text-white text-xs truncate">{photo?.caption}</p>
              </div>
            )}
          </div>
        ))}
      </div>
      {photos?.length > 6 && (
        <div className="mt-4 text-center">
          <Button
            variant="outline"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? 'Show Less' : `View All ${photos?.length} Photos`}
          </Button>
        </div>
      )}
      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={closeLightbox}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors"
            >
              <Icon name="X" size={20} />
            </button>
            
            <div className="relative">
              <Image
                src={selectedPhoto?.url}
                alt={selectedPhoto?.caption || `${eventTitle} photo`}
                className="max-w-full max-h-[80vh] object-contain"
              />
              
              {photos?.length > 1 && (
                <>
                  <button
                    onClick={() => navigatePhoto('prev')}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors"
                  >
                    <Icon name="ChevronLeft" size={20} />
                  </button>
                  <button
                    onClick={() => navigatePhoto('next')}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors"
                  >
                    <Icon name="ChevronRight" size={20} />
                  </button>
                </>
              )}
            </div>
            
            {selectedPhoto?.caption && (
              <div className="mt-4 text-center">
                <p className="text-white text-sm">{selectedPhoto?.caption}</p>
                <p className="text-white/70 text-xs mt-1">
                  {selectedPhoto?.index + 1} of {photos?.length}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default EventGallery;