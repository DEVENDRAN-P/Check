import React from 'react';
import Icon from '../../../components/AppIcon';

const RequirementsSection = ({ requirements, userSkills = [] }) => {
  if (!requirements || requirements?.length === 0) return null;

  const checkSkillMatch = (requirement) => {
    return userSkills?.some(skill => 
      requirement?.toLowerCase()?.includes(skill?.toLowerCase())
    );
  };

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <h2 className="text-xl font-semibold text-card-foreground mb-4">Requirements & Preparation</h2>
      <div className="space-y-3">
        {requirements?.map((requirement, index) => {
          const hasSkill = checkSkillMatch(requirement);
          
          return (
            <div key={index} className="flex items-start space-x-3">
              <div className={`mt-0.5 flex-shrink-0 ${
                hasSkill ? 'text-success' : 'text-text-secondary'
              }`}>
                <Icon 
                  name={hasSkill ? "CheckCircle" : "Circle"} 
                  size={16} 
                />
              </div>
              <div className="flex-1">
                <p className="text-text-secondary">{requirement}</p>
                {hasSkill && (
                  <p className="text-success text-xs mt-1 font-medium">
                    ✓ You have this skill
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-6 p-4 bg-accent/5 border border-accent/20 rounded-lg">
        <div className="flex items-start space-x-2">
          <Icon name="Info" size={16} className="text-accent mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-accent font-medium text-sm">Skill Matching</p>
            <p className="text-text-secondary text-sm mt-1">
              Based on your profile, you match {userSkills?.length} of the recommended skills for this event.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequirementsSection;