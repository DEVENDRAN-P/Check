import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LocationMap = ({ event }) => {
  const [showDirections, setShowDirections] = useState(false);

  const handleGetDirections = () => {
    const query = encodeURIComponent(event?.address || event?.location);
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  const handleShowDirections = () => {
    setShowDirections(!showDirections);
  };

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-card-foreground">Location</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={handleGetDirections}
          iconName="Navigation"
          iconPosition="left"
        >
          Directions
        </Button>
      </div>
      <div className="space-y-4">
        <div className="flex items-start space-x-3">
          <Icon name="MapPin" size={20} className="text-primary mt-1" />
          <div>
            <p className="font-medium text-card-foreground">{event?.location}</p>
            <p className="text-text-secondary text-sm">{event?.address}</p>
          </div>
        </div>
        
        {/* Map Widget */}
        <div className="w-full h-64 rounded-lg overflow-hidden border border-border">
          <iframe
            width="100%"
            height="100%"
            loading="lazy"
            title={event?.location}
            referrerPolicy="no-referrer-when-downgrade"
            src={`https://www.google.com/maps?q=${event?.coordinates?.lat || 40.7128},${event?.coordinates?.lng || -74.0060}&z=15&output=embed`}
            className="border-0"
          />
        </div>
        
        {/* Additional Location Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {event?.parking && (
            <div className="flex items-center space-x-2">
              <Icon name="Car" size={16} className="text-text-secondary" />
              <span className="text-text-secondary">Parking: {event?.parking}</span>
            </div>
          )}
          
          {event?.accessibility && (
            <div className="flex items-center space-x-2">
              <Icon name="Accessibility" size={16} className="text-text-secondary" />
              <span className="text-text-secondary">Wheelchair accessible</span>
            </div>
          )}
          
          {event?.publicTransport && (
            <div className="flex items-center space-x-2">
              <Icon name="Bus" size={16} className="text-text-secondary" />
              <span className="text-text-secondary">Public transport nearby</span>
            </div>
          )}
          
          {event?.nearbyLandmarks && (
            <div className="flex items-center space-x-2">
              <Icon name="MapPin" size={16} className="text-text-secondary" />
              <span className="text-text-secondary">Near {event?.nearbyLandmarks}</span>
            </div>
          )}
        </div>
        
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShowDirections}
            iconName="Route"
            iconPosition="left"
          >
            Show Route
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconName="Share2"
            iconPosition="left"
          >
            Share Location
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconName="Phone"
            iconPosition="left"
          >
            Call Venue
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LocationMap;