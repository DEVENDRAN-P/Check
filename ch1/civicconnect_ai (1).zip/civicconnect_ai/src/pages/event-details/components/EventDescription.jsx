import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const EventDescription = ({ event }) => {
  const [showFullDescription, setShowFullDescription] = useState(false);
  
  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  const shortDescription = event?.description?.length > 300 
    ? event?.description?.substring(0, 300) + '...' 
    : event?.description;

  return (
    <div className="bg-card rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-card-foreground">About This Event</h2>
        {event?.aiSummary && (
          <div className="flex items-center space-x-2 px-3 py-1 bg-accent/10 text-accent rounded-full">
            <Icon name="Sparkles" size={16} />
            <span className="text-sm font-medium">AI Summary</span>
          </div>
        )}
      </div>
      {event?.aiSummary && (
        <div className="mb-6 p-4 bg-accent/5 border border-accent/20 rounded-lg">
          <h3 className="font-medium text-card-foreground mb-2">Quick Summary</h3>
          <p className="text-text-secondary text-sm leading-relaxed">{event?.aiSummary}</p>
        </div>
      )}
      <div className="prose prose-sm max-w-none">
        <p className="text-text-secondary leading-relaxed">
          {showFullDescription ? event?.description : shortDescription}
        </p>
        
        {event?.description?.length > 300 && (
          <button
            onClick={toggleDescription}
            className="mt-3 text-primary hover:text-primary/80 font-medium text-sm transition-smooth"
          >
            {showFullDescription ? 'Show Less' : 'Read More'}
          </button>
        )}
      </div>
      {event?.highlights && (
        <div className="mt-6">
          <h3 className="font-medium text-card-foreground mb-3">Event Highlights</h3>
          <ul className="space-y-2">
            {event?.highlights?.map((highlight, index) => (
              <li key={index} className="flex items-start space-x-2">
                <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                <span className="text-text-secondary text-sm">{highlight}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default EventDescription;