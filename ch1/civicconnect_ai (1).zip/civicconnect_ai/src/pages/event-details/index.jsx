import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Header from '../../components/ui/Header';
import AIChatWidget from '../../components/ui/AIChatWidget';
import EventHero from './components/EventHero';
import EventInfo from './components/EventInfo';
import EventDescription from './components/EventDescription';
import OrganizerInfo from './components/OrganizerInfo';
import ParticipationPanel from './components/ParticipationPanel';
import RequirementsSection from './components/RequirementsSection';
import SocialProofSection from './components/SocialProofSection';
import LocationMap from './components/LocationMap';
import EventGallery from './components/EventGallery';
import Button from '../../components/ui/Button';


const EventDetails = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const eventId = searchParams?.get('id') || '1';
  const [loading, setLoading] = useState(true);

  // Mock event data
  const eventData = {
    id: eventId,
    title: "Community Garden Restoration Project",
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&h=600&fit=crop",
    date: "Saturday, December 14, 2024",
    time: "9:00 AM - 4:00 PM",
    location: "Riverside Community Garden",
    address: "1234 Garden Lane, Springfield, IL 62701",
    coordinates: { lat: 39.7817, lng: -89.6501 },
    attendees: 47,
    capacity: 60,
    cost: "Free",
    category: "Environmental",
    duration: "7 hours",
    tags: ["Environment", "Community", "Volunteering", "Outdoor"],
    description: `Join us for a transformative day of community service as we restore and revitalize the Riverside Community Garden. This hands-on volunteer opportunity brings together neighbors, families, and environmental enthusiasts to create a thriving green space that will benefit our entire community for years to come.\n\nWe'll be working on multiple restoration projects including soil preparation, planting native species, building raised garden beds, installing irrigation systems, and creating educational signage. This event is perfect for volunteers of all skill levels - from gardening novices to experienced horticulturists.\n\nThe garden serves over 200 local families and provides fresh produce to the Springfield Food Bank. Your contribution will directly impact food security in our community while creating a beautiful, sustainable space for education and recreation.`,
    aiSummary: "A community-driven environmental restoration project focused on revitalizing a local garden that serves 200+ families. Involves hands-on gardening, construction, and educational activities suitable for all skill levels.",
    highlights: [
      "Hands-on environmental restoration work",
      "Direct impact on local food security",
      "Educational workshops on sustainable gardening",
      "Community networking and team building",
      "Professional gardening tools provided",
      "Lunch and refreshments included"
    ],
    requirements: [
      "Comfortable outdoor clothing and closed-toe shoes",
      "Basic physical fitness for outdoor work",
      "Willingness to work with soil and plants",
      "Sun protection (hat, sunscreen)",
      "Water bottle for hydration"
    ],
    organizer: {
      name: "Sarah Martinez",
      role: "Environmental Program Coordinator",
      organization: "Springfield Green Initiative",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      verified: true,
      eventsOrganized: 23,
      rating: 4.8,
      followers: 342,
      bio: "Passionate environmental advocate with 8+ years of experience in community organizing and sustainable development. Dedicated to creating green spaces that bring communities together.",
      achievements: ["Green Leader 2024", "Community Champion", "Sustainability Expert"]
    },
    parking: "Free street parking available",
    accessibility: true,
    publicTransport: true,
    nearbyLandmarks: "Springfield Library",
    mutualConnections: [
      {
        name: "Mike Johnson",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
      },
      {
        name: "Lisa Chen",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
      },
      {
        name: "David Wilson",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
      }
    ],
    attendees: [
      {
        name: "Emma Thompson",
        role: "Environmental Science Student",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
        joinedTime: "2 hours ago"
      },
      {
        name: "Carlos Rodriguez",
        role: "Local Business Owner",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
        joinedTime: "5 hours ago"
      },
      {
        name: "Jennifer Kim",
        role: "Teacher",
        avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face",
        joinedTime: "1 day ago"
      },
      {
        name: "Robert Brown",
        role: "Retired Engineer",
        avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face",
        joinedTime: "2 days ago"
      },
      {
        name: "Maria Garcia",
        role: "Community Volunteer",
        avatar: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=150&h=150&fit=crop&crop=face",
        joinedTime: "3 days ago"
      }
    ],
    testimonials: [
      {
        name: "Alex Turner",
        avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=150&h=150&fit=crop&crop=face",
        rating: 5,
        comment: "Sarah\'s events are always well-organized and impactful. Last month\'s tree planting was amazing!",
        date: "2 weeks ago"
      },
      {
        name: "Rachel Green",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face",
        rating: 5,
        comment: "Great community building experience. Met wonderful people and learned so much about sustainable gardening.",
        date: "1 month ago"
      }
    ],
    photos: [
      {
        url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=400&fit=crop",
        caption: "Previous garden restoration work"
      },
      {
        url: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&h=400&fit=crop",
        caption: "Community volunteers in action"
      },
      {
        url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=400&fit=crop",
        caption: "Beautiful garden results"
      },
      {
        url: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=400&fit=crop",
        caption: "Team building activities"
      },
      {
        url: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&h=400&fit=crop",
        caption: "Educational workshops"
      },
      {
        url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=400&fit=crop",
        caption: "Fresh produce harvest"
      }
    ]
  };

  const userSkills = ["Gardening", "Environmental Science", "Community Organizing"];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleBackToEvents = () => {
    navigate('/dashboard');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16 pb-20 md:pb-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="animate-pulse">
              <div className="h-8 bg-muted rounded w-1/4 mb-6"></div>
              <div className="h-64 md:h-80 lg:h-96 bg-muted rounded-lg mb-6"></div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <div className="h-48 bg-muted rounded-lg"></div>
                  <div className="h-32 bg-muted rounded-lg"></div>
                  <div className="h-40 bg-muted rounded-lg"></div>
                </div>
                <div className="space-y-6">
                  <div className="h-64 bg-muted rounded-lg"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16 pb-20 md:pb-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Back Navigation */}
          <div className="mb-6">
            <Button
              variant="ghost"
              onClick={handleBackToEvents}
              iconName="ArrowLeft"
              iconPosition="left"
            >
              Back to Events
            </Button>
          </div>

          {/* Event Hero */}
          <EventHero event={eventData} />

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-8">
              <EventInfo event={eventData} />
              <EventDescription event={eventData} />
              <RequirementsSection 
                requirements={eventData?.requirements} 
                userSkills={userSkills} 
              />
              <OrganizerInfo organizer={eventData?.organizer} />
              <LocationMap event={eventData} />
              <SocialProofSection 
                attendees={eventData?.attendees}
                testimonials={eventData?.testimonials}
                mutualConnections={eventData?.mutualConnections}
              />
              <EventGallery 
                photos={eventData?.photos} 
                eventTitle={eventData?.title} 
              />
            </div>

            {/* Right Column - Participation Panel */}
            <div className="lg:col-span-1">
              <ParticipationPanel event={eventData} />
            </div>
          </div>
        </div>
      </div>
      <AIChatWidget />
    </div>
  );
};

export default EventDetails;