import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import AIChatWidget from '../../components/ui/AIChatWidget';
import EventDetailsModal from '../../components/ui/EventDetailsModal';
import EventCard from './components/EventCard';
import EventTabs from './components/EventTabs';
import EventFilters from './components/EventFilters';
import ImpactSummary from './components/ImpactSummary';
import EmptyState from './components/EmptyState';
import QuickActions from './components/QuickActions';

import Button from '../../components/ui/Button';

const MyEventsPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('attending');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('date-asc');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filteredEvents, setFilteredEvents] = useState([]);

  // Mock data for events
  const mockEvents = {
    attending: [
      {
        id: 1,
        title: "Community Garden Cleanup",
        description: "Join us for a morning of beautifying our local community garden. We'll be planting new flowers, removing weeds, and preparing the space for spring.",
        date: "2025-01-15",
        time: "09:00",
        location: "Riverside Community Garden, 123 Garden St",
        image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400&h=300&fit=crop",
        status: "confirmed",
        organizer: "Green Spaces Initiative",
        organizerRole: "Environmental Coordinator",
        category: "environmental",
        attendees: 24,
        capacity: 30,
        tags: ["Environment", "Community", "Outdoor"],
        requirements: [
          "Bring gardening gloves",
          "Wear comfortable clothes",
          "Water bottle recommended"
        ],
        impact: {
          trees_planted: 15,
          area_cleaned: "2 acres",
          volunteers: 30,
          hours_contributed: 120
        }
      },
      {
        id: 2,
        title: "Food Bank Volunteer Drive",
        description: "Help sort and package food donations for families in need. This is a great opportunity to make a direct impact on food insecurity in our community.",
        date: "2025-01-18",
        time: "14:00",
        location: "Central Food Bank, 456 Main Ave",
        image: "https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?w=400&h=300&fit=crop",
        status: "pending",
        organizer: "Community Food Network",
        organizerRole: "Volunteer Coordinator",
        category: "community-service",
        attendees: 18,
        capacity: 25,
        tags: ["Food Security", "Community Service", "Indoor"],
        requirements: [
          "Closed-toe shoes required",
          "Hair net will be provided",
          "No experience necessary"
        ],
        impact: {
          meals_packed: 500,
          families_served: 125,
          volunteers: 25,
          hours_contributed: 100
        }
      },
      {
        id: 3,
        title: "Youth Mentorship Program Kickoff",
        description: "Launch event for our new youth mentorship program. Meet the students you\'ll be mentoring and participate in team-building activities.",
        date: "2025-01-22",
        time: "16:30",
        location: "Lincoln High School, 789 Education Blvd",
        image: "https://images.pixabay.com/photo/2017/07/31/11/21/people-2557396_1280.jpg?w=400&h=300&fit=crop",
        status: "confirmed",
        organizer: "Future Leaders Foundation",
        organizerRole: "Program Director",
        category: "youth-development",
        attendees: 32,
        capacity: 40,
        tags: ["Education", "Mentorship", "Youth"],
        requirements: [
          "Background check completed",
          "Orientation session attended",
          "Commitment for 6 months"
        ],
        impact: {
          students_mentored: 40,
          mentors_trained: 32,
          sessions_planned: 24,
          graduation_rate_improvement: "15%"
        }
      }
    ],
    organizing: [
      {
        id: 4,
        title: "Neighborhood Safety Workshop",
        description: "Educational workshop on home security, emergency preparedness, and community watch programs. Open to all residents.",
        date: "2025-01-20",
        time: "19:00",
        location: "Community Center Hall A, 321 Center St",
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop",
        organizer: "John Doe",
        organizerRole: "Community Organizer",
        category: "community-service",
        attendees: 45,
        capacity: 60,
        registrationTrend: 12,
        tags: ["Safety", "Education", "Community"],
        requirements: [
          "Open to all ages",
          "Bring notepad for tips",
          "Light refreshments provided"
        ],
        impact: {
          residents_educated: 60,
          safety_tips_shared: 25,
          watch_groups_formed: 3,
          crime_reduction_target: "20%"
        }
      },
      {
        id: 5,
        title: "Senior Citizens Tech Support",
        description: "Help senior citizens learn to use smartphones, tablets, and computers. One-on-one assistance with basic digital literacy.",
        date: "2025-01-25",
        time: "10:00",
        location: "Senior Center, 654 Elder Way",
        image: "https://images.pexels.com/photos/7551659/pexels-photo-7551659.jpeg?w=400&h=300&fit=crop",
        organizer: "John Doe",
        organizerRole: "Community Organizer",
        category: "education",
        attendees: 28,
        capacity: 35,
        registrationTrend: 8,
        tags: ["Technology", "Seniors", "Education"],
        requirements: [
          "Bring your own device",
          "Patience and empathy required",
          "Basic tech knowledge helpful"
        ],
        impact: {
          seniors_helped: 35,
          devices_configured: 42,
          skills_taught: 15,
          digital_confidence_increase: "75%"
        }
      }
    ],
    past: [
      {
        id: 6,
        title: "Holiday Toy Drive",
        description: "Collected and distributed toys to underprivileged children during the holiday season. Brought joy to hundreds of families.",
        date: "2024-12-15",
        time: "09:00",
        location: "City Mall Central Court, 987 Shopping Blvd",
        image: "https://images.pixabay.com/photo/2017-12-09/21/33/christmas-3008687_1280.jpg?w=400&h=300&fit=crop",
        organizer: "Holiday Helpers Coalition",
        organizerRole: "Event Coordinator",
        category: "community-service",
        attendees: 67,
        volunteerHours: 8,
        badgeEarned: "Holiday Hero",
        feedbackSubmitted: true,
        rating: 5,
        tags: ["Holidays", "Children", "Community"],
        impact: {
          toys_collected: 450,
          children_served: 200,
          families_helped: 85,
          smiles_created: "Countless"
        }
      },
      {
        id: 7,
        title: "Beach Cleanup Initiative",
        description: "Removed plastic waste and debris from our local beach. Contributed to marine conservation and environmental protection.",
        date: "2024-11-28",
        time: "08:00",
        location: "Sunset Beach, Coastal Highway",
        image: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=300&fit=crop",
        organizer: "Ocean Guardians",
        organizerRole: "Environmental Activist",
        category: "environmental",
        attendees: 89,
        volunteerHours: 6,
        badgeEarned: "Ocean Protector",
        feedbackSubmitted: false,
        tags: ["Environment", "Ocean", "Conservation"],
        impact: {
          trash_collected: "245 lbs",
          beach_area_cleaned: "2.5 miles",
          marine_life_protected: "Thousands",
          awareness_raised: "High"
        }
      },
      {
        id: 8,
        title: "Literacy Program for Adults",
        description: "Taught basic reading and writing skills to adult learners. Empowered individuals to improve their employment opportunities.",
        date: "2024-10-10",
        time: "18:00",
        location: "Public Library Conference Room, 147 Book St",
        image: "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?w=400&h=300&fit=crop",
        organizer: "Literacy First Foundation",
        organizerRole: "Education Director",
        category: "education",
        attendees: 23,
        volunteerHours: 12,
        badgeEarned: "Knowledge Builder",
        feedbackSubmitted: true,
        rating: 4,
        tags: ["Education", "Literacy", "Adult Learning"],
        impact: {
          adults_taught: 23,
          reading_levels_improved: 18,
          job_applications_completed: 12,
          confidence_boost: "Significant"
        }
      }
    ]
  };

  // Mock impact data
  const impactData = {
    totalHours: 156,
    eventsAttended: 23,
    badgesEarned: 8,
    impactScore: 92,
    recentAchievements: [
      {
        title: "Community Champion Badge",
        date: "January 5, 2025"
      },
      {
        title: "50 Hours Milestone",
        date: "December 28, 2024"
      },
      {
        title: "Environmental Warrior Badge",
        date: "December 15, 2024"
      }
    ]
  };

  // Filter and sort events
  useEffect(() => {
    let events = mockEvents?.[activeTab] || [];

    // Apply search filter
    if (searchQuery) {
      events = events?.filter(event =>
        event?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        event?.location?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        event?.organizer?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        event?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    // Apply category filter
    if (categoryFilter !== 'all') {
      events = events?.filter(event => event?.category === categoryFilter);
    }

    // Apply sorting
    events?.sort((a, b) => {
      switch (sortBy) {
        case 'date-asc':
          return new Date(`${a.date} ${a.time}`) - new Date(`${b.date} ${b.time}`);
        case 'date-desc':
          return new Date(`${b.date} ${b.time}`) - new Date(`${a.date} ${a.time}`);
        case 'title-asc':
          return a?.title?.localeCompare(b?.title);
        case 'title-desc':
          return b?.title?.localeCompare(a?.title);
        case 'location':
          return a?.location?.localeCompare(b?.location);
        default:
          return 0;
      }
    });

    setFilteredEvents(events);
  }, [activeTab, searchQuery, sortBy, categoryFilter]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setSearchQuery('');
    setSortBy('date-asc');
    setCategoryFilter('all');
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSortBy('date-asc');
    setCategoryFilter('all');
  };

  const handleViewDetails = (event) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  const handleCheckIn = (event) => {
    console.log('Checking in to event:', event?.id);
    // Handle check-in logic
  };

  const handleMessage = (event) => {
    console.log('Opening message for event:', event?.id);
    // Handle messaging logic
  };

  const handleShare = (event) => {
    console.log('Sharing event:', event?.id);
    // Handle share logic
  };

  const handleEdit = (event) => {
    console.log('Editing event:', event?.id);
    // Handle edit logic
  };

  const handleCancel = (event) => {
    console.log('Cancelling event:', event?.id);
    // Handle cancel logic
  };

  const handleCreateEvent = () => {
    console.log('Creating new event');
    // Handle create event logic
  };

  const handleSyncCalendar = () => {
    console.log('Syncing calendar');
    // Handle calendar sync logic
  };

  const handleExportData = () => {
    console.log('Exporting data');
    // Handle data export logic
  };

  const handleViewAnalytics = () => {
    console.log('Viewing analytics');
    // Handle analytics view logic
  };

  const handleEmptyStateAction = () => {
    if (searchQuery || sortBy !== 'date-asc' || categoryFilter !== 'all') {
      handleClearFilters();
    } else {
      navigate('/dashboard');
    }
  };

  const eventCounts = {
    attending: mockEvents?.attending?.length,
    organizing: mockEvents?.organizing?.length,
    past: mockEvents?.past?.length
  };

  const hasEvents = filteredEvents?.length > 0;
  const isSearching = searchQuery || sortBy !== 'date-asc' || categoryFilter !== 'all';

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16 pb-20 md:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground">My Events</h1>
                <p className="text-text-secondary mt-1">
                  Manage your event participation and track your community impact
                </p>
              </div>
              <Button
                variant="default"
                onClick={handleCreateEvent}
                iconName="Plus"
                iconPosition="left"
              >
                Create Event
              </Button>
            </div>
          </div>

          {/* Impact Summary */}
          <div className="mb-8">
            <ImpactSummary impactData={impactData} />
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <QuickActions
              onCreateEvent={handleCreateEvent}
              onSyncCalendar={handleSyncCalendar}
              onExportData={handleExportData}
              onViewAnalytics={handleViewAnalytics}
            />
          </div>

          {/* Event Tabs */}
          <div className="bg-card border border-border rounded-lg">
            <div className="p-6 pb-0">
              <EventTabs
                activeTab={activeTab}
                onTabChange={handleTabChange}
                counts={eventCounts}
              />
            </div>

            {/* Filters */}
            <div className="p-6">
              <EventFilters
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                sortBy={sortBy}
                onSortChange={setSortBy}
                categoryFilter={categoryFilter}
                onCategoryChange={setCategoryFilter}
                onClearFilters={handleClearFilters}
              />
            </div>

            {/* Events List */}
            <div className="p-6 pt-0">
              {hasEvents ? (
                <div className="space-y-6">
                  {filteredEvents?.map((event) => (
                    <EventCard
                      key={event?.id}
                      event={event}
                      type={activeTab}
                      onViewDetails={handleViewDetails}
                      onCheckIn={handleCheckIn}
                      onMessage={handleMessage}
                      onShare={handleShare}
                      onEdit={handleEdit}
                      onCancel={handleCancel}
                    />
                  ))}
                </div>
              ) : (
                <EmptyState
                  type={isSearching ? 'search' : activeTab}
                  onAction={handleEmptyStateAction}
                />
              )}
            </div>
          </div>
        </div>
      </main>
      {/* Event Details Modal */}
      <EventDetailsModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        event={selectedEvent}
      />
      {/* AI Chat Widget */}
      <AIChatWidget />
    </div>
  );
};

export default MyEventsPage;