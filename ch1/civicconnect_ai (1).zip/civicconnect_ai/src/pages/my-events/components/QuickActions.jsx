import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = ({ onCreateEvent, onSyncCalendar, onExportData, onViewAnalytics }) => {
  const actions = [
    {
      icon: 'Plus',
      label: 'Create Event',
      description: 'Start organizing a new community event',
      onClick: onCreateEvent,
      variant: 'default'
    },
    {
      icon: 'Calendar',
      label: 'Sync Calendar',
      description: 'Connect with Google Calendar',
      onClick: onSyncCalendar,
      variant: 'outline'
    },
    {
      icon: 'Download',
      label: 'Export Data',
      description: 'Download your event history',
      onClick: onExportData,
      variant: 'outline'
    },
    {
      icon: 'BarChart3',
      label: 'View Analytics',
      description: 'See your participation insights',
      onClick: onViewAnalytics,
      variant: 'outline'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h3 className="text-lg font-semibold text-card-foreground mb-4">Quick Actions</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {actions?.map((action, index) => (
          <button
            key={index}
            onClick={action?.onClick}
            className="flex flex-col items-center p-4 border border-border rounded-lg hover:bg-surface hover:border-primary/20 transition-smooth text-center group"
          >
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-smooth">
              <Icon name={action?.icon} size={24} className="text-primary" />
            </div>
            
            <h4 className="font-medium text-card-foreground mb-1 text-sm">
              {action?.label}
            </h4>
            
            <p className="text-xs text-text-secondary leading-relaxed">
              {action?.description}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;