import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const EventFilters = ({ 
  searchQuery, 
  onSearchChange, 
  sortBy, 
  onSortChange, 
  categoryFilter, 
  onCategoryChange,
  onClearFilters 
}) => {
  const sortOptions = [
    { value: 'date-asc', label: 'Date (Earliest First)' },
    { value: 'date-desc', label: 'Date (Latest First)' },
    { value: 'title-asc', label: 'Title (A-Z)' },
    { value: 'title-desc', label: 'Title (Z-A)' },
    { value: 'location', label: 'Location' }
  ];

  const categoryOptions = [
    { value: 'all', label: 'All Categories' },
    { value: 'community-service', label: 'Community Service' },
    { value: 'environmental', label: 'Environmental' },
    { value: 'education', label: 'Education' },
    { value: 'healthcare', label: 'Healthcare' },
    { value: 'social-justice', label: 'Social Justice' },
    { value: 'arts-culture', label: 'Arts & Culture' },
    { value: 'disaster-relief', label: 'Disaster Relief' },
    { value: 'youth-development', label: 'Youth Development' }
  ];

  const hasActiveFilters = searchQuery || sortBy !== 'date-asc' || categoryFilter !== 'all';

  return (
    <div className="bg-surface border border-border rounded-lg p-4 space-y-4">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Search */}
        <div className="flex-1">
          <Input
            type="search"
            placeholder="Search events by title, location, or organizer..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e?.target?.value)}
            className="w-full"
          />
        </div>

        {/* Sort */}
        <div className="w-full lg:w-48">
          <Select
            placeholder="Sort by..."
            options={sortOptions}
            value={sortBy}
            onChange={onSortChange}
          />
        </div>

        {/* Category Filter */}
        <div className="w-full lg:w-48">
          <Select
            placeholder="Filter by category..."
            options={categoryOptions}
            value={categoryFilter}
            onChange={onCategoryChange}
          />
        </div>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button
            variant="outline"
            size="default"
            onClick={onClearFilters}
            iconName="X"
            iconPosition="left"
          >
            Clear
          </Button>
        )}
      </div>
      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
          <span className="text-sm text-text-secondary">Active filters:</span>
          {searchQuery && (
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
              Search: "{searchQuery}"
            </span>
          )}
          {sortBy !== 'date-asc' && (
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
              Sort: {sortOptions?.find(opt => opt?.value === sortBy)?.label}
            </span>
          )}
          {categoryFilter !== 'all' && (
            <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
              Category: {categoryOptions?.find(opt => opt?.value === categoryFilter)?.label}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default EventFilters;