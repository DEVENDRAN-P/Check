import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const EmptyState = ({ type, onAction }) => {
  const getEmptyStateContent = () => {
    switch (type) {
      case 'attending':
        return {
          icon: 'Calendar',
          title: 'No Upcoming Events',
          description: 'You haven\'t signed up for any events yet. Discover amazing opportunities to make a difference in your community.',
          actionText: 'Browse Events',
          actionIcon: 'Search'
        };
      case 'organizing':
        return {
          icon: 'Users',
          title: 'No Events to Organize',
          description: 'Start making an impact by creating your first community event. Bring people together for a cause you care about.',
          actionText: 'Create Event',
          actionIcon: 'Plus'
        };
      case 'past':
        return {
          icon: 'History',
          title: 'No Past Events',
          description: 'Your event history will appear here once you start participating in community activities.',
          actionText: 'Find Events',
          actionIcon: 'Search'
        };
      case 'search':
        return {
          icon: 'Search',
          title: 'No Events Found',
          description: 'We couldn\'t find any events matching your search criteria. Try adjusting your filters or search terms.',
          actionText: 'Clear Filters',
          actionIcon: 'X'
        };
      default:
        return {
          icon: 'Calendar',
          title: 'No Events',
          description: 'There are no events to display at the moment.',
          actionText: 'Refresh',
          actionIcon: 'RefreshCw'
        };
    }
  };

  const content = getEmptyStateContent();

  return (
    <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
        <Icon name={content?.icon} size={32} className="text-text-secondary" />
      </div>
      <h3 className="text-lg font-semibold text-card-foreground mb-2">
        {content?.title}
      </h3>
      <p className="text-text-secondary mb-6 max-w-md">
        {content?.description}
      </p>
      <Button
        variant="default"
        onClick={onAction}
        iconName={content?.actionIcon}
        iconPosition="left"
      >
        {content?.actionText}
      </Button>
    </div>
  );
};

export default EmptyState;