import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const EventCard = ({ event, type, onViewDetails, onCheckIn, onMessage, onShare, onEdit, onCancel }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01 ${timeString}`)?.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getTimeUntilEvent = (date, time) => {
    const eventDateTime = new Date(`${date} ${time}`);
    const now = new Date();
    const diffMs = eventDateTime - now;
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return 'Past event';
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    return `${diffDays} days`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'text-success bg-success/10';
      case 'pending': return 'text-warning bg-warning/10';
      case 'cancelled': return 'text-destructive bg-destructive/10';
      default: return 'text-text-secondary bg-muted';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 hover:shadow-elevated transition-smooth">
      <div className="flex flex-col lg:flex-row lg:items-start gap-4">
        {/* Event Image */}
        <div className="w-full lg:w-32 h-32 rounded-lg overflow-hidden flex-shrink-0">
          <Image
            src={event?.image}
            alt={event?.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Event Details */}
        <div className="flex-1 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
            <h3 className="text-lg font-semibold text-card-foreground line-clamp-2">
              {event?.title}
            </h3>
            {type === 'attending' && (
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(event?.status)}`}>
                {event?.status}
              </span>
            )}
          </div>

          <div className="flex flex-wrap gap-4 text-sm text-text-secondary">
            <div className="flex items-center space-x-2">
              <Icon name="Calendar" size={16} />
              <span>{formatDate(event?.date)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} />
              <span>{formatTime(event?.time)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="MapPin" size={16} />
              <span className="truncate">{event?.location}</span>
            </div>
            {type !== 'past' && (
              <div className="flex items-center space-x-2">
                <Icon name="Timer" size={16} />
                <span className="font-medium text-primary">
                  {getTimeUntilEvent(event?.date, event?.time)}
                </span>
              </div>
            )}
          </div>

          {type === 'organizing' && (
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center space-x-2 text-text-secondary">
                <Icon name="Users" size={16} />
                <span>{event?.attendees}/{event?.capacity} attending</span>
              </div>
              <div className="flex items-center space-x-2 text-success">
                <Icon name="TrendingUp" size={16} />
                <span>{event?.registrationTrend}% this week</span>
              </div>
            </div>
          )}

          {type === 'past' && event?.volunteerHours && (
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center space-x-2 text-primary">
                <Icon name="Clock" size={16} />
                <span>{event?.volunteerHours} hours contributed</span>
              </div>
              {event?.badgeEarned && (
                <div className="flex items-center space-x-2 text-accent">
                  <Icon name="Award" size={16} />
                  <span>Badge earned: {event?.badgeEarned}</span>
                </div>
              )}
            </div>
          )}

          <p className="text-text-secondary text-sm line-clamp-2">
            {event?.description}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 min-w-fit">
          <Button
            variant="default"
            size="sm"
            onClick={() => onViewDetails(event)}
            iconName="Eye"
            iconPosition="left"
          >
            View Details
          </Button>

          {type === 'attending' && event?.status === 'confirmed' && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onCheckIn(event)}
                iconName="CheckCircle"
                iconPosition="left"
              >
                Check In
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onMessage(event)}
                iconName="MessageCircle"
                iconPosition="left"
              >
                Message
              </Button>
            </>
          )}

          {type === 'organizing' && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(event)}
                iconName="Edit"
                iconPosition="left"
              >
                Edit Event
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onMessage(event)}
                iconName="Users"
                iconPosition="left"
              >
                Manage
              </Button>
            </>
          )}

          {type === 'past' && !event?.feedbackSubmitted && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewDetails(event)}
              iconName="Star"
              iconPosition="left"
            >
              Rate Event
            </Button>
          )}

          <Button
            variant="ghost"
            size="sm"
            onClick={() => onShare(event)}
            iconName="Share2"
            iconPosition="left"
          >
            Share
          </Button>

          {type === 'attending' && event?.status === 'pending' && (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => onCancel(event)}
              iconName="X"
              iconPosition="left"
            >
              Cancel
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EventCard;