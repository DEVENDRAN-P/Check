import React from 'react';
import Icon from '../../../components/AppIcon';

const EventTabs = ({ activeTab, onTabChange, counts }) => {
  const tabs = [
    {
      id: 'attending',
      label: 'Attending',
      icon: 'Calendar',
      count: counts?.attending
    },
    {
      id: 'organizing',
      label: 'Organizing',
      icon: 'Users',
      count: counts?.organizing
    },
    {
      id: 'past',
      label: 'Past Events',
      icon: 'History',
      count: counts?.past
    }
  ];

  return (
    <div className="border-b border-border">
      <nav className="flex space-x-8 overflow-x-auto">
        {tabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => onTabChange(tab?.id)}
            className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-smooth ${
              activeTab === tab?.id
                ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-foreground hover:border-border'
            }`}
          >
            <Icon name={tab?.icon} size={18} />
            <span>{tab?.label}</span>
            {tab?.count > 0 && (
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                activeTab === tab?.id
                  ? 'bg-primary/10 text-primary' :'bg-muted text-text-secondary'
              }`}>
                {tab?.count}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default EventTabs;