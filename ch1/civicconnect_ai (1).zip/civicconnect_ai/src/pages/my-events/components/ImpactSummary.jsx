import React from 'react';
import Icon from '../../../components/AppIcon';

const ImpactSummary = ({ impactData }) => {
  const impactMetrics = [
    {
      icon: 'Clock',
      label: 'Total Hours',
      value: impactData?.totalHours,
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      icon: 'Users',
      label: 'Events Attended',
      value: impactData?.eventsAttended,
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      icon: 'Award',
      label: 'Badges Earned',
      value: impactData?.badgesEarned,
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      icon: 'TrendingUp',
      label: 'Impact Score',
      value: impactData?.impactScore,
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-card-foreground">Your Impact Summary</h3>
        <div className="flex items-center space-x-2 text-sm text-text-secondary">
          <Icon name="Calendar" size={16} />
          <span>This Year</span>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {impactMetrics?.map((metric, index) => (
          <div key={index} className="text-center">
            <div className={`w-12 h-12 ${metric?.bgColor} rounded-full flex items-center justify-center mx-auto mb-3`}>
              <Icon name={metric?.icon} size={24} className={metric?.color} />
            </div>
            <p className="text-2xl font-bold text-card-foreground mb-1">{metric?.value}</p>
            <p className="text-sm text-text-secondary">{metric?.label}</p>
          </div>
        ))}
      </div>
      {/* Recent Achievements */}
      {impactData?.recentAchievements && impactData?.recentAchievements?.length > 0 && (
        <div className="mt-6 pt-6 border-t border-border">
          <h4 className="text-sm font-medium text-card-foreground mb-3">Recent Achievements</h4>
          <div className="space-y-2">
            {impactData?.recentAchievements?.map((achievement, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 bg-surface rounded-md">
                <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="Award" size={16} className="text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-card-foreground truncate">
                    {achievement?.title}
                  </p>
                  <p className="text-xs text-text-secondary">
                    {achievement?.date}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ImpactSummary;