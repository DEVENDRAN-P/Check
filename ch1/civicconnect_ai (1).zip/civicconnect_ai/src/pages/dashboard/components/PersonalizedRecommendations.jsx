import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PersonalizedRecommendations = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);

  const recommendations = [
    {
      id: 1,
      title: "Community Garden Cleanup",
      date: "Sep 15, 2025",
      time: "9:00 AM - 12:00 PM",
      location: "Central Park Community Garden",
      matchPercentage: 95,
      image: "https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=400",
      tags: ["Environment", "Outdoor", "Community"],
      attendees: 24,
      organizer: "Green Earth Initiative",
      description: "Join us for a morning of community service as we clean and maintain our local community garden. Perfect for nature lovers!"
    },
    {
      id: 2,
      title: "Youth Mentorship Program",
      date: "Sep 18, 2025",
      time: "2:00 PM - 5:00 PM",
      location: "Downtown Community Center",
      matchPercentage: 88,
      image: "https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg?auto=compress&cs=tinysrgb&w=400",
      tags: ["Education", "Youth", "Mentoring"],
      attendees: 15,
      organizer: "Future Leaders Foundation",
      description: "Share your skills and experience with local youth. Help shape the next generation of community leaders."
    },
    {
      id: 3,
      title: "Food Bank Distribution",
      date: "Sep 20, 2025",
      time: "8:00 AM - 1:00 PM",
      location: "Riverside Food Bank",
      matchPercentage: 82,
      image: "https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg?auto=compress&cs=tinysrgb&w=400",
      tags: ["Food Security", "Community", "Service"],
      attendees: 32,
      organizer: "Riverside Community Services",
      description: "Help distribute food packages to families in need. Make a direct impact on food security in our community."
    },
    {
      id: 4,
      title: "Senior Tech Support Workshop",
      date: "Sep 22, 2025",
      time: "10:00 AM - 2:00 PM",
      location: "Silver Age Center",
      matchPercentage: 76,
      image: "https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=400",
      tags: ["Technology", "Seniors", "Education"],
      attendees: 18,
      organizer: "Digital Inclusion Project",
      description: "Teach seniors how to use smartphones and computers. Bridge the digital divide in our community."
    }
  ];

  const handleEventClick = (eventId) => {
    navigate('/event-details', { state: { eventId } });
  };

  const handleRSVP = (eventId, e) => {
    e?.stopPropagation();
    console.log('RSVP for event:', eventId);
    // Handle RSVP logic
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % recommendations?.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + recommendations?.length) % recommendations?.length);
  };

  const getMatchColor = (percentage) => {
    if (percentage >= 90) return 'text-success';
    if (percentage >= 80) return 'text-accent';
    return 'text-secondary';
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-card-foreground">Recommended for You</h2>
          <p className="text-sm text-text-secondary">AI-powered event suggestions based on your interests</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" onClick={prevSlide}>
            <Icon name="ChevronLeft" size={20} />
          </Button>
          <Button variant="ghost" size="icon" onClick={nextSlide}>
            <Icon name="ChevronRight" size={20} />
          </Button>
        </div>
      </div>
      {/* Desktop Grid View */}
      <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {recommendations?.map((event) => (
          <div
            key={event?.id}
            onClick={() => handleEventClick(event?.id)}
            className="bg-surface rounded-lg border border-border hover:shadow-elevated transition-smooth cursor-pointer group"
          >
            <div className="relative h-32 overflow-hidden rounded-t-lg">
              <Image
                src={event?.image}
                alt={event?.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
              />
              <div className={`absolute top-2 right-2 px-2 py-1 bg-background/90 rounded-full text-xs font-medium ${getMatchColor(event?.matchPercentage)}`}>
                {event?.matchPercentage}% match
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-medium text-card-foreground mb-2 line-clamp-2">{event?.title}</h3>
              <div className="space-y-1 mb-3">
                <div className="flex items-center text-xs text-text-secondary">
                  <Icon name="Calendar" size={12} className="mr-1" />
                  <span>{event?.date}</span>
                </div>
                <div className="flex items-center text-xs text-text-secondary">
                  <Icon name="MapPin" size={12} className="mr-1" />
                  <span className="truncate">{event?.location}</span>
                </div>
                <div className="flex items-center text-xs text-text-secondary">
                  <Icon name="Users" size={12} className="mr-1" />
                  <span>{event?.attendees} attending</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-3">
                {event?.tags?.slice(0, 2)?.map((tag) => (
                  <span key={tag} className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">
                    {tag}
                  </span>
                ))}
              </div>
              <Button
                variant="outline"
                size="sm"
                fullWidth
                onClick={(e) => handleRSVP(event?.id, e)}
                iconName="UserPlus"
                iconPosition="left"
              >
                RSVP
              </Button>
            </div>
          </div>
        ))}
      </div>
      {/* Mobile Carousel View */}
      <div className="md:hidden">
        <div className="relative overflow-hidden">
          <div
            className="flex transition-transform duration-300 ease-in-out"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {recommendations?.map((event) => (
              <div
                key={event?.id}
                className="w-full flex-shrink-0 px-2"
                onClick={() => handleEventClick(event?.id)}
              >
                <div className="bg-surface rounded-lg border border-border cursor-pointer">
                  <div className="relative h-40 overflow-hidden rounded-t-lg">
                    <Image
                      src={event?.image}
                      alt={event?.title}
                      className="w-full h-full object-cover"
                    />
                    <div className={`absolute top-2 right-2 px-2 py-1 bg-background/90 rounded-full text-xs font-medium ${getMatchColor(event?.matchPercentage)}`}>
                      {event?.matchPercentage}% match
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-card-foreground mb-2">{event?.title}</h3>
                    <div className="space-y-2 mb-3">
                      <div className="flex items-center text-sm text-text-secondary">
                        <Icon name="Calendar" size={14} className="mr-2" />
                        <span>{event?.date}</span>
                      </div>
                      <div className="flex items-center text-sm text-text-secondary">
                        <Icon name="MapPin" size={14} className="mr-2" />
                        <span>{event?.location}</span>
                      </div>
                      <div className="flex items-center text-sm text-text-secondary">
                        <Icon name="Users" size={14} className="mr-2" />
                        <span>{event?.attendees} attending</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {event?.tags?.map((tag) => (
                        <span key={tag} className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={(e) => handleRSVP(event?.id, e)}
                      iconName="UserPlus"
                      iconPosition="left"
                    >
                      RSVP
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Carousel Indicators */}
        <div className="flex justify-center space-x-2 mt-4">
          {recommendations?.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-smooth ${
                index === currentSlide ? 'bg-primary' : 'bg-border'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default PersonalizedRecommendations;