import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = ({ onOpenAIChat }) => {
  const navigate = useNavigate();

  const actions = [
    {
      id: 'find-events',
      label: 'Find Events',
      icon: 'Search',
      description: 'Discover new volunteer opportunities',
      color: 'primary',
      onClick: () => navigate('/my-events')
    },
    {
      id: 'create-event',
      label: 'Create Event',
      icon: 'Plus',
      description: 'Organize a community event',
      color: 'success',
      onClick: () => console.log('Create event clicked')
    },
    {
      id: 'ai-chat',
      label: 'AI Assistant',
      icon: 'MessageCircle',
      description: 'Get personalized recommendations',
      color: 'accent',
      onClick: onOpenAIChat
    },
    {
      id: 'my-profile',
      label: 'My Profile',
      icon: 'User',
      description: 'Update your preferences',
      color: 'secondary',
      onClick: () => navigate('/profile-settings')
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: 'bg-primary/10 text-primary hover:bg-primary/20',
      success: 'bg-success/10 text-success hover:bg-success/20',
      accent: 'bg-accent/10 text-accent hover:bg-accent/20',
      secondary: 'bg-secondary/10 text-secondary hover:bg-secondary/20'
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-card-foreground">Quick Actions</h2>
        <p className="text-sm text-text-secondary">Get started with common tasks</p>
      </div>
      {/* Desktop Grid */}
      <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {actions?.map((action) => (
          <button
            key={action?.id}
            onClick={action?.onClick}
            className={`p-4 rounded-lg transition-smooth text-left ${getColorClasses(action?.color)}`}
          >
            <div className="flex items-center space-x-3 mb-2">
              <Icon name={action?.icon} size={20} />
              <span className="font-medium">{action?.label}</span>
            </div>
            <p className="text-xs opacity-80">{action?.description}</p>
          </button>
        ))}
      </div>
      {/* Mobile List */}
      <div className="md:hidden space-y-3">
        {actions?.map((action) => (
          <button
            key={action?.id}
            onClick={action?.onClick}
            className={`w-full p-4 rounded-lg transition-smooth text-left ${getColorClasses(action?.color)}`}
          >
            <div className="flex items-center space-x-3">
              <Icon name={action?.icon} size={20} />
              <div>
                <p className="font-medium">{action?.label}</p>
                <p className="text-xs opacity-80">{action?.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
      {/* Featured Action */}
      <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-card-foreground">Try AI Recommendations</h3>
            <p className="text-sm text-text-secondary">Get personalized event suggestions based on your interests</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenAIChat}
            iconName="Sparkles"
            iconPosition="left"
          >
            Ask AI
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;