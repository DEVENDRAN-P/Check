import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NotificationsWidget = () => {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'reminder',
      title: 'Event Reminder',
      message: 'Community Garden Cleanup starts in 2 hours',
      timestamp: new Date(Date.now() - 300000), // 5 minutes ago
      read: false,
      actionLabel: 'View Event',
      icon: 'Bell'
    },
    {
      id: 2,
      type: 'rsvp',
      title: 'RSVP Confirmed',
      message: 'Your attendance for Youth Mentorship Program has been confirmed',
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      read: false,
      actionLabel: 'View Details',
      icon: 'CheckCircle'
    },
    {
      id: 3,
      type: 'achievement',
      title: 'New Badge Earned!',
      message: 'You\'ve earned the "Community Champion" badge',
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      read: true,
      actionLabel: 'View Badge',
      icon: 'Award'
    },
    {
      id: 4,
      type: 'update',
      title: 'Community Update',
      message: 'Sarah Johnson completed 50 volunteer hours this month!',
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      read: true,
      actionLabel: 'View Profile',
      icon: 'Users'
    },
    {
      id: 5,
      type: 'invitation',
      title: 'Event Invitation',
      message: 'You\'ve been invited to join the Food Bank Distribution event',
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      read: true,
      actionLabel: 'Respond',
      icon: 'Mail'
    }
  ]);

  const [showAll, setShowAll] = useState(false);

  const markAsRead = (notificationId) => {
    setNotifications(prev =>
      prev?.map(notification =>
        notification?.id === notificationId
          ? { ...notification, read: true }
          : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev?.map(notification => ({ ...notification, read: true }))
    );
  };

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const getNotificationColor = (type) => {
    const colorMap = {
      reminder: 'text-accent',
      rsvp: 'text-success',
      achievement: 'text-primary',
      update: 'text-secondary',
      invitation: 'text-destructive'
    };
    return colorMap?.[type] || 'text-text-secondary';
  };

  const unreadCount = notifications?.filter(n => !n?.read)?.length;
  const displayNotifications = showAll ? notifications : notifications?.slice(0, 3);

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-semibold text-card-foreground">Notifications</h2>
          {unreadCount > 0 && (
            <span className="px-2 py-1 bg-destructive text-destructive-foreground text-xs rounded-full">
              {unreadCount}
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={markAllAsRead}>
            Mark all read
          </Button>
        )}
      </div>
      {notifications?.length === 0 ? (
        <div className="text-center py-8">
          <Icon name="Bell" size={48} className="text-text-secondary mx-auto mb-3" />
          <p className="text-text-secondary">No notifications yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {displayNotifications?.map((notification) => (
            <div
              key={notification?.id}
              className={`p-4 rounded-lg border transition-smooth cursor-pointer ${
                notification?.read
                  ? 'bg-surface border-border' :'bg-primary/5 border-primary/20'
              }`}
              onClick={() => markAsRead(notification?.id)}
            >
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  notification?.read ? 'bg-border' : 'bg-primary/10'
                }`}>
                  <Icon
                    name={notification?.icon}
                    size={16}
                    className={notification?.read ? 'text-text-secondary' : getNotificationColor(notification?.type)}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className={`font-medium ${
                      notification?.read ? 'text-text-secondary' : 'text-card-foreground'
                    }`}>
                      {notification?.title}
                    </h3>
                    <span className="text-xs text-text-secondary">
                      {getTimeAgo(notification?.timestamp)}
                    </span>
                  </div>
                  <p className={`text-sm ${
                    notification?.read ? 'text-text-secondary' : 'text-card-foreground'
                  }`}>
                    {notification?.message}
                  </p>
                  {notification?.actionLabel && (
                    <button className={`text-xs mt-2 ${
                      notification?.read ? 'text-text-secondary' : 'text-primary'
                    } hover:underline`}>
                      {notification?.actionLabel}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {notifications?.length > 3 && (
        <div className="mt-4 text-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAll(!showAll)}
            iconName={showAll ? 'ChevronUp' : 'ChevronDown'}
            iconPosition="right"
          >
            {showAll ? 'Show Less' : `Show ${notifications?.length - 3} More`}
          </Button>
        </div>
      )}
    </div>
  );
};

export default NotificationsWidget;