import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';

const MonthlyImpactChart = () => {
  const monthlyData = [
    { month: 'Mar', hours: 18, events: 4 },
    { month: 'Apr', hours: 25, events: 6 },
    { month: 'May', hours: 32, events: 8 },
    { month: 'Jun', hours: 28, events: 7 },
    { month: 'Jul', hours: 35, events: 9 },
    { month: 'Aug', hours: 42, events: 11 },
    { month: 'Sep', hours: 32, events: 8 }
  ];

  const achievementMilestones = [
    { milestone: '100 Hours', achieved: true, date: 'Aug 15' },
    { milestone: '50 Events', achieved: false, progress: 23 },
    { milestone: '10 Badges', achieved: false, progress: 8 }
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-popover border border-border rounded-lg p-3 shadow-elevated">
          <p className="font-medium text-popover-foreground">{`${label} 2025`}</p>
          <p className="text-sm text-primary">{`Hours: ${payload?.[0]?.value}`}</p>
          <p className="text-sm text-success">{`Events: ${payload?.[1]?.value}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-card-foreground mb-2">Monthly Impact Summary</h2>
        <p className="text-sm text-text-secondary">Your volunteer participation trends over time</p>
      </div>
      {/* Chart */}
      <div className="mb-6">
        <div className="h-64" aria-label="Monthly Impact Bar Chart">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis
                dataKey="month"
                stroke="var(--color-text-secondary)"
                fontSize={12}
              />
              <YAxis
                stroke="var(--color-text-secondary)"
                fontSize={12}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="hours"
                fill="var(--color-primary)"
                radius={[2, 2, 0, 0]}
                name="Hours"
              />
              <Bar
                dataKey="events"
                fill="var(--color-success)"
                radius={[2, 2, 0, 0]}
                name="Events"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center space-x-6 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded"></div>
            <span className="text-sm text-text-secondary">Volunteer Hours</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success rounded"></div>
            <span className="text-sm text-text-secondary">Events Attended</span>
          </div>
        </div>
      </div>
      {/* Achievement Milestones */}
      <div>
        <h3 className="font-medium text-card-foreground mb-4">Achievement Milestones</h3>
        <div className="space-y-3">
          {achievementMilestones?.map((milestone, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-surface rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  milestone?.achieved
                    ? 'bg-success/10 text-success' :'bg-border text-text-secondary'
                }`}>
                  <Icon
                    name={milestone?.achieved ? 'CheckCircle' : 'Circle'}
                    size={16}
                  />
                </div>
                <div>
                  <p className="font-medium text-card-foreground">{milestone?.milestone}</p>
                  {milestone?.achieved ? (
                    <p className="text-xs text-success">Achieved on {milestone?.date}</p>
                  ) : (
                    <p className="text-xs text-text-secondary">
                      Progress: {milestone?.progress}/{milestone?.milestone?.split(' ')?.[0]}
                    </p>
                  )}
                </div>
              </div>
              {!milestone?.achieved && (
                <div className="w-16 bg-border rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all duration-500"
                    style={{
                      width: `${(milestone?.progress / parseInt(milestone?.milestone?.split(' ')?.[0])) * 100}%`
                    }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      {/* Summary Stats */}
      <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-success/5 border border-primary/20 rounded-lg">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-semibold text-primary">127</p>
            <p className="text-xs text-text-secondary">Total Hours</p>
          </div>
          <div>
            <p className="text-2xl font-semibold text-success">23</p>
            <p className="text-xs text-text-secondary">Total Events</p>
          </div>
          <div>
            <p className="text-2xl font-semibold text-accent">8</p>
            <p className="text-xs text-text-secondary">Badges</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonthlyImpactChart;