import React from 'react';
import Icon from '../../../components/AppIcon';

const ImpactMetrics = () => {
  const metrics = {
    totalHours: 127,
    eventsAttended: 23,
    badgesEarned: 8,
    leaderboardPosition: 12,
    monthlyGoal: 40,
    currentMonthHours: 32
  };

  const badges = [
    { name: "Community Champion", icon: "Award", color: "text-accent", earned: true },
    { name: "Environmental Hero", icon: "Leaf", color: "text-success", earned: true },
    { name: "Youth Mentor", icon: "Users", color: "text-primary", earned: true },
    { name: "Tech Helper", icon: "Laptop", color: "text-secondary", earned: false },
    { name: "Food Security Advocate", icon: "Heart", color: "text-destructive", earned: true }
  ];

  const progressPercentage = (metrics?.currentMonthHours / metrics?.monthlyGoal) * 100;

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-card-foreground mb-2">Your Impact</h2>
        <p className="text-sm text-text-secondary">Track your volunteer contributions and achievements</p>
      </div>
      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-surface rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
            <Icon name="Clock" size={20} className="text-primary" />
          </div>
          <p className="text-2xl font-semibold text-card-foreground">{metrics?.totalHours}</p>
          <p className="text-xs text-text-secondary">Total Hours</p>
        </div>

        <div className="bg-surface rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-2">
            <Icon name="Calendar" size={20} className="text-success" />
          </div>
          <p className="text-2xl font-semibold text-card-foreground">{metrics?.eventsAttended}</p>
          <p className="text-xs text-text-secondary">Events Attended</p>
        </div>

        <div className="bg-surface rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-2">
            <Icon name="Award" size={20} className="text-accent" />
          </div>
          <p className="text-2xl font-semibold text-card-foreground">{metrics?.badgesEarned}</p>
          <p className="text-xs text-text-secondary">Badges Earned</p>
        </div>

        <div className="bg-surface rounded-lg p-4 text-center">
          <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-2">
            <Icon name="TrendingUp" size={20} className="text-secondary" />
          </div>
          <p className="text-2xl font-semibold text-card-foreground">#{metrics?.leaderboardPosition}</p>
          <p className="text-xs text-text-secondary">Leaderboard</p>
        </div>
      </div>
      {/* Monthly Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-medium text-card-foreground">September Goal Progress</h3>
          <span className="text-sm text-text-secondary">
            {metrics?.currentMonthHours}/{metrics?.monthlyGoal} hours
          </span>
        </div>
        <div className="w-full bg-border rounded-full h-2">
          <div
            className="bg-primary h-2 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${Math.min(progressPercentage, 100)}%` }}
          />
        </div>
        <p className="text-xs text-text-secondary mt-1">
          {progressPercentage >= 100 ? 'Goal achieved! 🎉' : `${Math.round(progressPercentage)}% complete`}
        </p>
      </div>
      {/* Badges Section */}
      <div>
        <h3 className="font-medium text-card-foreground mb-3">Achievement Badges</h3>
        <div className="grid grid-cols-5 gap-3">
          {badges?.map((badge, index) => (
            <div key={index} className="text-center">
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-1 transition-smooth ${
                  badge?.earned
                    ? `bg-${badge?.color?.split('-')?.[1]}/10 ${badge?.color}`
                    : 'bg-border text-text-secondary opacity-50'
                }`}
              >
                <Icon name={badge?.icon} size={20} />
              </div>
              <p className={`text-xs ${badge?.earned ? 'text-card-foreground' : 'text-text-secondary'}`}>
                {badge?.name?.split(' ')?.[0]}
              </p>
            </div>
          ))}
        </div>
      </div>
      {/* Recent Achievement */}
      <div className="mt-6 p-4 bg-success/5 border border-success/20 rounded-lg">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-success/10 rounded-full flex items-center justify-center">
            <Icon name="Trophy" size={20} className="text-success" />
          </div>
          <div>
            <p className="font-medium text-card-foreground">New Badge Earned!</p>
            <p className="text-sm text-text-secondary">You've earned the "Community Champion" badge for attending 20+ events</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImpactMetrics;