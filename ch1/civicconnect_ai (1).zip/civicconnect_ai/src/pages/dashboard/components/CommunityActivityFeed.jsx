import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const CommunityActivityFeed = () => {
  const [activities] = useState([
    {
      id: 1,
      type: 'achievement',
      user: 'Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150',
      action: 'earned the Environmental Hero badge',
      details: 'Completed 25 hours of environmental volunteer work',
      timestamp: new Date(Date.now() - 900000), // 15 minutes ago
      likes: 12,
      comments: 3
    },
    {
      id: 2,
      type: 'event_completion',
      user: 'Michael Chen',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      action: 'completed Community Garden Cleanup',
      details: 'Helped plant 50 new flowers and removed invasive weeds',
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      likes: 8,
      comments: 2,
      eventImage: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 3,
      type: 'milestone',
      user: 'Emma Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
      action: 'reached 100 volunteer hours',
      details: 'Celebrating a major milestone in community service!',
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      likes: 24,
      comments: 7
    },
    {
      id: 4,
      type: 'event_join',
      user: 'David Park',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      action: 'joined Youth Mentorship Program',
      details: 'Looking forward to sharing tech skills with local students',
      timestamp: new Date(Date.now() - 5400000), // 1.5 hours ago
      likes: 6,
      comments: 1
    },
    {
      id: 5,
      type: 'event_creation',
      user: 'Lisa Thompson',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
      action: 'created Senior Tech Support Workshop',
      details: 'Help seniors learn to use smartphones and tablets',
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      likes: 15,
      comments: 4,
      eventImage: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ]);

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  const getActivityIcon = (type) => {
    const iconMap = {
      achievement: 'Award',
      event_completion: 'CheckCircle',
      milestone: 'Trophy',
      event_join: 'UserPlus',
      event_creation: 'Plus'
    };
    return iconMap?.[type] || 'Activity';
  };

  const getActivityColor = (type) => {
    const colorMap = {
      achievement: 'text-accent',
      event_completion: 'text-success',
      milestone: 'text-primary',
      event_join: 'text-secondary',
      event_creation: 'text-destructive'
    };
    return colorMap?.[type] || 'text-text-secondary';
  };

  const handleLike = (activityId) => {
    console.log('Liked activity:', activityId);
  };

  const handleComment = (activityId) => {
    console.log('Comment on activity:', activityId);
  };

  const handleShare = (activityId) => {
    console.log('Share activity:', activityId);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-card-foreground">Community Activity</h2>
          <p className="text-sm text-text-secondary">Recent achievements and events from your community</p>
        </div>
        <Button variant="ghost" size="sm" iconName="RefreshCw" iconPosition="left">
          Refresh
        </Button>
      </div>
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {activities?.map((activity) => (
          <div key={activity?.id} className="p-4 bg-surface rounded-lg border border-border">
            <div className="flex items-start space-x-3">
              {/* User Avatar */}
              <div className="relative">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <Image
                    src={activity?.avatar}
                    alt={activity?.user}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center bg-background border-2 border-background ${getActivityColor(activity?.type)}`}>
                  <Icon name={getActivityIcon(activity?.type)} size={12} />
                </div>
              </div>

              {/* Activity Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm">
                    <span className="font-medium text-card-foreground">{activity?.user}</span>
                    <span className="text-text-secondary"> {activity?.action}</span>
                  </p>
                  <span className="text-xs text-text-secondary">
                    {getTimeAgo(activity?.timestamp)}
                  </span>
                </div>

                <p className="text-sm text-text-secondary mb-3">{activity?.details}</p>

                {/* Event Image if present */}
                {activity?.eventImage && (
                  <div className="mb-3 rounded-lg overflow-hidden">
                    <Image
                      src={activity?.eventImage}
                      alt="Event"
                      className="w-full h-32 object-cover"
                    />
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleLike(activity?.id)}
                    className="flex items-center space-x-1 text-text-secondary hover:text-primary transition-smooth"
                  >
                    <Icon name="Heart" size={14} />
                    <span className="text-xs">{activity?.likes}</span>
                  </button>
                  <button
                    onClick={() => handleComment(activity?.id)}
                    className="flex items-center space-x-1 text-text-secondary hover:text-primary transition-smooth"
                  >
                    <Icon name="MessageCircle" size={14} />
                    <span className="text-xs">{activity?.comments}</span>
                  </button>
                  <button
                    onClick={() => handleShare(activity?.id)}
                    className="flex items-center space-x-1 text-text-secondary hover:text-primary transition-smooth"
                  >
                    <Icon name="Share2" size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Load More */}
      <div className="mt-4 text-center">
        <Button variant="ghost" size="sm" iconName="ChevronDown" iconPosition="right">
          Load More Activities
        </Button>
      </div>
    </div>
  );
};

export default CommunityActivityFeed;