import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import AIChatWidget from '../../components/ui/AIChatWidget';
import PersonalizedRecommendations from './components/PersonalizedRecommendations';
import ImpactMetrics from './components/ImpactMetrics';
import QuickActions from './components/QuickActions';
import NotificationsWidget from './components/NotificationsWidget';
import MonthlyImpactChart from './components/MonthlyImpactChart';
import CommunityActivityFeed from './components/CommunityActivityFeed';

const Dashboard = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const handleOpenAIChat = () => {
    setIsChatOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Main Content */}
      <main className="pt-16 pb-20 md:pb-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-foreground mb-2">
              Welcome back, John! 👋
            </h1>
            <p className="text-text-secondary">
              Here's what's happening in your community today
            </p>
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <QuickActions onOpenAIChat={handleOpenAIChat} />
          </div>

          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Left Column - Recommendations and Charts */}
            <div className="lg:col-span-2 space-y-8">
              <PersonalizedRecommendations />
              <MonthlyImpactChart />
            </div>

            {/* Right Column - Metrics and Notifications */}
            <div className="space-y-8">
              <ImpactMetrics />
              <NotificationsWidget />
            </div>
          </div>

          {/* Community Activity Feed */}
          <div className="mb-8">
            <CommunityActivityFeed />
          </div>
        </div>
      </main>

      {/* AI Chat Widget */}
      <AIChatWidget />
    </div>
  );
};

export default Dashboard;