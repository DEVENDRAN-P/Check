import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  return (
    <div className="space-y-4">
      {/* Security Badges */}
      <div className="flex items-center justify-center space-x-6">
        <div className="flex items-center space-x-2 text-success">
          <Icon name="Shield" size={16} />
          <span className="text-xs font-medium">SSL Secured</span>
        </div>
        
        <div className="flex items-center space-x-2 text-success">
          <Icon name="Lock" size={16} />
          <span className="text-xs font-medium">256-bit Encryption</span>
        </div>
      </div>
      {/* Privacy Links */}
      <div className="flex items-center justify-center space-x-4 text-xs text-text-secondary">
        <button className="hover:text-primary transition-smooth">
          Privacy Policy
        </button>
        <span>•</span>
        <button className="hover:text-primary transition-smooth">
          Terms of Service
        </button>
        <span>•</span>
        <button className="hover:text-primary transition-smooth">
          Help Center
        </button>
      </div>
      {/* Community Trust */}
      <div className="text-center">
        <p className="text-xs text-text-secondary">
          Trusted by 10,000+ community organizers worldwide
        </p>
        <div className="flex items-center justify-center space-x-1 mt-2">
          {[...Array(5)]?.map((_, i) => (
            <Icon key={i} name="Star" size={12} className="text-accent fill-current" />
          ))}
          <span className="text-xs text-text-secondary ml-2">4.9/5 rating</span>
        </div>
      </div>
    </div>
  );
};

export default TrustSignals;