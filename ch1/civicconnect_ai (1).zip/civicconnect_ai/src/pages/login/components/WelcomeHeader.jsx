import React from 'react';
import Icon from '../../../components/AppIcon';

const WelcomeHeader = () => {
  return (
    <div className="text-center space-y-4 mb-8">
      {/* Logo */}
      <div className="flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
            <Icon name="Users" size={24} color="white" />
          </div>
          <div className="text-left">
            <h1 className="text-2xl font-bold text-foreground">CivicConnect AI</h1>
            <p className="text-sm text-text-secondary">Community Engagement Platform</p>
          </div>
        </div>
      </div>

      {/* Welcome Message */}
      <div className="space-y-2">
        <h2 className="text-xl font-semibold text-foreground">Welcome Back</h2>
        <p className="text-text-secondary">
          Sign in to your account to continue organizing and participating in community events
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4 py-4 px-6 bg-surface rounded-lg">
        <div className="text-center">
          <div className="text-lg font-semibold text-primary">2.5K+</div>
          <div className="text-xs text-text-secondary">Active Events</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold text-success">15K+</div>
          <div className="text-xs text-text-secondary">Volunteers</div>
        </div>
        <div className="text-center">
          <div className="text-lg font-semibold text-accent">500+</div>
          <div className="text-xs text-text-secondary">Organizations</div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeHeader;