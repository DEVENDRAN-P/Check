import React from 'react';
import Button from '../../../components/ui/Button';


const SocialAuth = () => {
  const handleGoogleAuth = () => {
    // Handle Google authentication
    alert('Google authentication would be handled here');
  };

  const handleMicrosoftAuth = () => {
    // Handle Microsoft authentication
    alert('Microsoft authentication would be handled here');
  };

  return (
    <div className="space-y-4">
      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-background text-text-secondary">Or continue with</span>
        </div>
      </div>

      {/* Social Auth Buttons */}
      <div className="grid grid-cols-1 gap-3">
        <Button
          variant="outline"
          fullWidth
          onClick={handleGoogleAuth}
          iconName="Chrome"
          iconPosition="left"
        >
          Continue with Google
        </Button>
        
        <Button
          variant="outline"
          fullWidth
          onClick={handleMicrosoftAuth}
          iconName="Windows"
          iconPosition="left"
        >
          Continue with Microsoft
        </Button>
      </div>
    </div>
  );
};

export default SocialAuth;