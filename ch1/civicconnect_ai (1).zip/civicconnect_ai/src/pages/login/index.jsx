import React, { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import WelcomeHeader from './components/WelcomeHeader';
import LoginForm from './components/LoginForm';
import SocialAuth from './components/SocialAuth';
import TrustSignals from './components/TrustSignals';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const Login = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/dashboard');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-surface to-muted">
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="w-full max-w-lg">
          {/* Main Login Card */}
          <div className="bg-card border border-border rounded-xl shadow-elevated p-8">
            {/* Welcome Header */}
            <WelcomeHeader />

            {/* Login Form */}
            <LoginForm />

            {/* Social Authentication */}
            <div className="mt-6">
              <SocialAuth />
            </div>

            {/* Create Account Link */}
            <div className="mt-6 text-center">
              <p className="text-sm text-text-secondary">
                Don't have an account?{' '}
                <Link
                  to="/register"
                  className="text-primary hover:text-primary/80 font-medium transition-smooth"
                >
                  Create Account
                </Link>
              </p>
            </div>
          </div>

          {/* Trust Signals */}
          <div className="mt-6">
            <TrustSignals />
          </div>

          {/* Additional Navigation */}
          <div className="mt-6 text-center">
            <div className="flex items-center justify-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                iconName="ArrowLeft"
                iconPosition="left"
                onClick={() => navigate('/')}
              >
                Back to Home
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                iconName="HelpCircle"
                iconPosition="left"
                onClick={() => alert('Help center would open here')}
              >
                Need Help?
              </Button>
            </div>
          </div>

          {/* Demo Credentials Notice */}
          <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-lg">
            <div className="flex items-start space-x-2">
              <Icon name="Info" size={16} className="text-accent mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-accent mb-1">Demo Access</p>
                <p className="text-text-secondary">
                  Use <strong>admin@civicconnect.com</strong> and password <strong>admin123</strong> to explore the platform
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Background Pattern */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-success/3 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
};

export default Login;