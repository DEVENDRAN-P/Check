import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const NotificationPreferencesSection = ({ userProfile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [preferences, setPreferences] = useState(userProfile?.notificationPreferences || {
    email: {
      eventRecommendations: true,
      rsvpConfirmations: true,
      eventReminders: true,
      communityUpdates: false,
      weeklyDigest: true,
      newEvents: true,
      eventChanges: true,
      achievements: true
    },
    push: {
      eventRecommendations: true,
      rsvpConfirmations: true,
      eventReminders: true,
      communityUpdates: false,
      newEvents: false,
      eventChanges: true,
      achievements: true
    },
    inApp: {
      eventRecommendations: true,
      rsvpConfirmations: true,
      eventReminders: true,
      communityUpdates: true,
      newEvents: true,
      eventChanges: true,
      achievements: true
    }
  });

  const notificationTypes = [
    {
      key: 'eventRecommendations',
      label: 'Event Recommendations',
      description: 'AI-powered suggestions based on your interests',
      icon: 'Sparkles'
    },
    {
      key: 'rsvpConfirmations',
      label: 'RSVP Confirmations',
      description: 'Confirmations when you join or leave events',
      icon: 'CheckCircle'
    },
    {
      key: 'eventReminders',
      label: 'Event Reminders',
      description: 'Reminders before events you\'ve joined',
      icon: 'Bell'
    },
    {
      key: 'communityUpdates',
      label: 'Community Updates',
      description: 'News and updates from your community',
      icon: 'Users'
    },
    {
      key: 'weeklyDigest',
      label: 'Weekly Digest',
      description: 'Summary of your activity and upcoming events',
      icon: 'Calendar'
    },
    {
      key: 'newEvents',
      label: 'New Events',
      description: 'Notifications when new events are posted',
      icon: 'Plus'
    },
    {
      key: 'eventChanges',
      label: 'Event Changes',
      description: 'Updates when events you\'ve joined are modified',
      icon: 'Edit'
    },
    {
      key: 'achievements',
      label: 'Achievements & Badges',
      description: 'Celebrate your volunteer milestones',
      icon: 'Award'
    }
  ];

  const channels = [
    { key: 'email', label: 'Email', icon: 'Mail' },
    { key: 'push', label: 'Push Notifications', icon: 'Smartphone' },
    { key: 'inApp', label: 'In-App Notifications', icon: 'Bell' }
  ];

  const handlePreferenceChange = (channel, type) => {
    setPreferences(prev => ({
      ...prev,
      [channel]: {
        ...prev?.[channel],
        [type]: !prev?.[channel]?.[type]
      }
    }));
  };

  const handleChannelToggle = (channel, enabled) => {
    setPreferences(prev => ({
      ...prev,
      [channel]: Object.keys(prev?.[channel])?.reduce((acc, key) => ({
        ...acc,
        [key]: enabled
      }), {})
    }));
  };

  const handleSave = () => {
    onUpdateProfile({
      notificationPreferences: preferences
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setPreferences(userProfile?.notificationPreferences || {
      email: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: false,
        weeklyDigest: true,
        newEvents: true,
        eventChanges: true,
        achievements: true
      },
      push: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: false,
        newEvents: false,
        eventChanges: true,
        achievements: true
      },
      inApp: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: true,
        newEvents: true,
        eventChanges: true,
        achievements: true
      }
    });
    setIsEditing(false);
  };

  const getChannelEnabledCount = (channel) => {
    return Object.values(preferences?.[channel])?.filter(Boolean)?.length;
  };

  const getTotalNotificationTypes = () => {
    return notificationTypes?.length;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-card-foreground">Notification Preferences</h2>
          <p className="text-sm text-text-secondary mt-1">
            Control how and when you receive updates from CivicConnect AI
          </p>
        </div>
        {!isEditing ? (
          <Button variant="outline" onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
            Edit
          </Button>
        ) : (
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant="default" onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-6">
        {/* Channel Overview */}
        {!isEditing && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {channels?.map(channel => (
              <div key={channel?.key} className="p-4 bg-surface rounded-lg">
                <div className="flex items-center space-x-3 mb-2">
                  <Icon name={channel?.icon} size={20} className="text-primary" />
                  <h3 className="font-medium text-card-foreground">{channel?.label}</h3>
                </div>
                <p className="text-sm text-text-secondary">
                  {getChannelEnabledCount(channel?.key)} of {getTotalNotificationTypes()} enabled
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Detailed Preferences */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="text-left py-3 px-3 text-sm font-medium text-card-foreground border-b border-border">
                  Notification Type
                </th>
                {channels?.map(channel => (
                  <th key={channel?.key} className="text-center py-3 px-3 text-sm font-medium text-card-foreground border-b border-border">
                    <div className="flex items-center justify-center space-x-2">
                      <Icon name={channel?.icon} size={16} />
                      <span>{channel?.label}</span>
                      {isEditing && (
                        <div className="flex space-x-1 ml-2">
                          <button
                            onClick={() => handleChannelToggle(channel?.key, true)}
                            className="text-xs px-2 py-1 bg-success/10 text-success rounded hover:bg-success/20 transition-smooth"
                          >
                            All
                          </button>
                          <button
                            onClick={() => handleChannelToggle(channel?.key, false)}
                            className="text-xs px-2 py-1 bg-destructive/10 text-destructive rounded hover:bg-destructive/20 transition-smooth"
                          >
                            None
                          </button>
                        </div>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {notificationTypes?.map(type => (
                <tr key={type?.key} className="border-b border-border hover:bg-surface/50">
                  <td className="py-4 px-3">
                    <div className="flex items-start space-x-3">
                      <Icon name={type?.icon} size={18} className="text-text-secondary mt-0.5" />
                      <div>
                        <h4 className="font-medium text-card-foreground">{type?.label}</h4>
                        <p className="text-sm text-text-secondary">{type?.description}</p>
                      </div>
                    </div>
                  </td>
                  {channels?.map(channel => (
                    <td key={channel?.key} className="py-4 px-3 text-center">
                      <Checkbox
                        checked={preferences?.[channel?.key]?.[type?.key]}
                        onChange={() => isEditing && handlePreferenceChange(channel?.key, type?.key)}
                        disabled={!isEditing}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Notification Timing */}
        <div className="p-4 bg-surface rounded-lg">
          <div className="flex items-start space-x-3">
            <Icon name="Clock" size={20} className="text-accent mt-0.5" />
            <div>
              <h4 className="font-medium text-card-foreground">Smart Timing</h4>
              <p className="text-sm text-text-secondary mt-1">
                Our AI learns your engagement patterns to send notifications at optimal times. 
                Event reminders are sent 24 hours and 1 hour before events based on your preferences.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationPreferencesSection;