import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Image from '../../../components/AppImage';

const PersonalInfoSection = ({ userProfile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: userProfile?.name || '',
    email: userProfile?.email || '',
    phone: userProfile?.phone || '',
    bio: userProfile?.bio || '',
    profilePhoto: userProfile?.profilePhoto || ''
  });
  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors?.[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData?.name?.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData?.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/?.test(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (formData?.phone && !/^\+?[\d\s\-\(\)]+$/?.test(formData?.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      onUpdateProfile(formData);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      name: userProfile?.name || '',
      email: userProfile?.email || '',
      phone: userProfile?.phone || '',
      bio: userProfile?.bio || '',
      profilePhoto: userProfile?.profilePhoto || ''
    });
    setErrors({});
    setIsEditing(false);
  };

  const handlePhotoUpload = (e) => {
    const file = e?.target?.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({
          ...prev,
          profilePhoto: event?.target?.result
        }));
      };
      reader?.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-card-foreground">Personal Information</h2>
        {!isEditing ? (
          <Button variant="outline" onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
            Edit
          </Button>
        ) : (
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant="default" onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-6">
        {/* Profile Photo */}
        <div className="flex items-center space-x-6">
          <div className="relative">
            <div className="w-20 h-20 rounded-full overflow-hidden bg-surface border-2 border-border">
              {formData?.profilePhoto ? (
                <Image
                  src={formData?.profilePhoto}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Icon name="User" size={32} className="text-text-secondary" />
                </div>
              )}
            </div>
            {isEditing && (
              <label className="absolute -bottom-2 -right-2 w-8 h-8 bg-primary rounded-full flex items-center justify-center cursor-pointer hover:bg-primary/90 transition-smooth">
                <Icon name="Camera" size={16} color="white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            )}
          </div>
          <div>
            <h3 className="font-medium text-card-foreground">Profile Photo</h3>
            <p className="text-sm text-text-secondary">Upload a photo to help community members recognize you</p>
          </div>
        </div>

        {/* Form Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Full Name"
            name="name"
            type="text"
            value={formData?.name}
            onChange={handleInputChange}
            error={errors?.name}
            disabled={!isEditing}
            required
            placeholder="Enter your full name"
          />

          <Input
            label="Email Address"
            name="email"
            type="email"
            value={formData?.email}
            onChange={handleInputChange}
            error={errors?.email}
            disabled={!isEditing}
            required
            placeholder="Enter your email address"
          />

          <Input
            label="Phone Number"
            name="phone"
            type="tel"
            value={formData?.phone}
            onChange={handleInputChange}
            error={errors?.phone}
            disabled={!isEditing}
            placeholder="Enter your phone number"
            description="Optional - for event organizers to contact you"
          />
        </div>

        {/* Bio */}
        <div>
          <label className="block text-sm font-medium text-card-foreground mb-2">
            Bio
          </label>
          <textarea
            name="bio"
            value={formData?.bio}
            onChange={handleInputChange}
            disabled={!isEditing}
            placeholder="Tell the community about yourself, your interests, and what motivates your civic engagement..."
            rows={4}
            className={`w-full px-3 py-2 border border-border rounded-md text-sm transition-smooth ${
              isEditing 
                ? 'bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent' :'bg-surface text-text-secondary'
            }`}
          />
          <p className="text-xs text-text-secondary mt-1">
            Share your background and what drives your community involvement
          </p>
        </div>
      </div>
    </div>
  );
};

export default PersonalInfoSection;