import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const LocationAvailabilitySection = ({ userProfile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [locationData, setLocationData] = useState({
    address: userProfile?.address || '',
    city: userProfile?.city || '',
    state: userProfile?.state || '',
    zipCode: userProfile?.zipCode || '',
    radius: userProfile?.radius || 10,
    showExactLocation: userProfile?.showExactLocation || false,
    showInDirectory: userProfile?.showInDirectory || true
  });
  
  const [availability, setAvailability] = useState(userProfile?.availability || {
    monday: { morning: false, afternoon: false, evening: false },
    tuesday: { morning: false, afternoon: false, evening: false },
    wednesday: { morning: false, afternoon: false, evening: false },
    thursday: { morning: false, afternoon: false, evening: false },
    friday: { morning: false, afternoon: false, evening: false },
    saturday: { morning: false, afternoon: false, evening: false },
    sunday: { morning: false, afternoon: false, evening: false }
  });

  const [errors, setErrors] = useState({});

  const days = [
    { key: 'monday', label: 'Monday' },
    { key: 'tuesday', label: 'Tuesday' },
    { key: 'wednesday', label: 'Wednesday' },
    { key: 'thursday', label: 'Thursday' },
    { key: 'friday', label: 'Friday' },
    { key: 'saturday', label: 'Saturday' },
    { key: 'sunday', label: 'Sunday' }
  ];

  const timeSlots = [
    { key: 'morning', label: 'Morning', time: '6AM - 12PM' },
    { key: 'afternoon', label: 'Afternoon', time: '12PM - 6PM' },
    { key: 'evening', label: 'Evening', time: '6PM - 10PM' }
  ];

  const handleLocationChange = (e) => {
    const { name, value, type, checked } = e?.target;
    setLocationData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors?.[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleAvailabilityChange = (day, timeSlot) => {
    setAvailability(prev => ({
      ...prev,
      [day]: {
        ...prev?.[day],
        [timeSlot]: !prev?.[day]?.[timeSlot]
      }
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!locationData?.city?.trim()) {
      newErrors.city = 'City is required';
    }
    
    if (!locationData?.state?.trim()) {
      newErrors.state = 'State is required';
    }
    
    if (locationData?.zipCode && !/^\d{5}(-\d{4})?$/?.test(locationData?.zipCode)) {
      newErrors.zipCode = 'Please enter a valid ZIP code';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      onUpdateProfile({
        ...locationData,
        availability
      });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setLocationData({
      address: userProfile?.address || '',
      city: userProfile?.city || '',
      state: userProfile?.state || '',
      zipCode: userProfile?.zipCode || '',
      radius: userProfile?.radius || 10,
      showExactLocation: userProfile?.showExactLocation || false,
      showInDirectory: userProfile?.showInDirectory || true
    });
    setAvailability(userProfile?.availability || {
      monday: { morning: false, afternoon: false, evening: false },
      tuesday: { morning: false, afternoon: false, evening: false },
      wednesday: { morning: false, afternoon: false, evening: false },
      thursday: { morning: false, afternoon: false, evening: false },
      friday: { morning: false, afternoon: false, evening: false },
      saturday: { morning: false, afternoon: false, evening: false },
      sunday: { morning: false, afternoon: false, evening: false }
    });
    setErrors({});
    setIsEditing(false);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-card-foreground">Location & Availability</h2>
          <p className="text-sm text-text-secondary mt-1">
            Set your location and availability for better event matching
          </p>
        </div>
        {!isEditing ? (
          <Button variant="outline" onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
            Edit
          </Button>
        ) : (
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant="default" onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8">
        {/* Location Settings */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-card-foreground flex items-center">
            <Icon name="MapPin" size={20} className="mr-2" />
            Location Settings
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Street Address"
              name="address"
              type="text"
              value={locationData?.address}
              onChange={handleLocationChange}
              disabled={!isEditing}
              placeholder="123 Main Street"
              description="Optional - for precise event matching"
            />

            <Input
              label="City"
              name="city"
              type="text"
              value={locationData?.city}
              onChange={handleLocationChange}
              error={errors?.city}
              disabled={!isEditing}
              required
              placeholder="Enter your city"
            />

            <Input
              label="State"
              name="state"
              type="text"
              value={locationData?.state}
              onChange={handleLocationChange}
              error={errors?.state}
              disabled={!isEditing}
              required
              placeholder="Enter your state"
            />

            <Input
              label="ZIP Code"
              name="zipCode"
              type="text"
              value={locationData?.zipCode}
              onChange={handleLocationChange}
              error={errors?.zipCode}
              disabled={!isEditing}
              placeholder="12345"
            />
          </div>

          <div className="space-y-4">
            <Input
              label="Search Radius (miles)"
              name="radius"
              type="number"
              value={locationData?.radius}
              onChange={handleLocationChange}
              disabled={!isEditing}
              min="1"
              max="100"
              description="How far are you willing to travel for events?"
            />

            <div className="space-y-3">
              <Checkbox
                label="Show exact location to event organizers"
                checked={locationData?.showExactLocation}
                onChange={(e) => handleLocationChange({
                  target: { name: 'showExactLocation', type: 'checkbox', checked: e?.target?.checked }
                })}
                disabled={!isEditing}
                description="Helps organizers provide specific directions and logistics"
              />

              <Checkbox
                label="Include me in community member directory"
                checked={locationData?.showInDirectory}
                onChange={(e) => handleLocationChange({
                  target: { name: 'showInDirectory', type: 'checkbox', checked: e?.target?.checked }
                })}
                disabled={!isEditing}
                description="Allow other community members to find and connect with you"
              />
            </div>
          </div>
        </div>

        {/* Availability Settings */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-card-foreground flex items-center">
            <Icon name="Clock" size={20} className="mr-2" />
            Weekly Availability
          </h3>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="text-left py-2 px-3 text-sm font-medium text-card-foreground">Day</th>
                  {timeSlots?.map(slot => (
                    <th key={slot?.key} className="text-center py-2 px-3 text-sm font-medium text-card-foreground">
                      <div>{slot?.label}</div>
                      <div className="text-xs text-text-secondary font-normal">{slot?.time}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {days?.map(day => (
                  <tr key={day?.key} className="border-t border-border">
                    <td className="py-3 px-3 font-medium text-card-foreground">{day?.label}</td>
                    {timeSlots?.map(slot => (
                      <td key={slot?.key} className="py-3 px-3 text-center">
                        <Checkbox
                          checked={availability?.[day?.key]?.[slot?.key]}
                          onChange={() => isEditing && handleAvailabilityChange(day?.key, slot?.key)}
                          disabled={!isEditing}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-surface rounded-lg">
            <div className="flex items-start space-x-3">
              <Icon name="Info" size={20} className="text-primary mt-0.5" />
              <div>
                <h4 className="font-medium text-card-foreground">Smart Matching</h4>
                <p className="text-sm text-text-secondary mt-1">
                  Our AI uses your availability to suggest events that fit your schedule and send timely reminders.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationAvailabilitySection;