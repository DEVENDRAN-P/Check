import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const IntegrationsSection = ({ userProfile, onUpdateProfile }) => {
  const [integrations, setIntegrations] = useState(userProfile?.integrations || {
    googleCalendar: {
      connected: false,
      email: '',
      syncEvents: true,
      syncReminders: true,
      lastSync: null
    },
    slack: {
      connected: false,
      workspace: '',
      channel: '',
      notifications: true,
      lastSync: null
    },
    notion: {
      connected: false,
      database: '',
      syncVolunteerHours: true,
      syncAchievements: false,
      lastSync: null
    }
  });

  const handleConnect = (service) => {
    // Simulate connection process
    const mockData = {
      googleCalendar: {
        connected: true,
        email: 'john.doe@gmail.com',
        syncEvents: true,
        syncReminders: true,
        lastSync: new Date()?.toISOString()
      },
      slack: {
        connected: true,
        workspace: 'CivicConnect Community',
        channel: '#general',
        notifications: true,
        lastSync: new Date()?.toISOString()
      },
      notion: {
        connected: true,
        database: 'Volunteer Tracker',
        syncVolunteerHours: true,
        syncAchievements: false,
        lastSync: new Date()?.toISOString()
      }
    };

    setIntegrations(prev => ({
      ...prev,
      [service]: mockData?.[service]
    }));

    onUpdateProfile({
      integrations: {
        ...integrations,
        [service]: mockData?.[service]
      }
    });
  };

  const handleDisconnect = (service) => {
    const disconnectedState = {
      connected: false,
      lastSync: null
    };

    setIntegrations(prev => ({
      ...prev,
      [service]: {
        ...prev?.[service],
        ...disconnectedState
      }
    }));

    onUpdateProfile({
      integrations: {
        ...integrations,
        [service]: {
          ...integrations?.[service],
          ...disconnectedState
        }
      }
    });
  };

  const handleSettingToggle = (service, setting) => {
    setIntegrations(prev => ({
      ...prev,
      [service]: {
        ...prev?.[service],
        [setting]: !prev?.[service]?.[setting]
      }
    }));

    onUpdateProfile({
      integrations: {
        ...integrations,
        [service]: {
          ...integrations?.[service],
          [setting]: !integrations?.[service]?.[setting]
        }
      }
    });
  };

  const formatLastSync = (lastSync) => {
    if (!lastSync) return 'Never';
    const date = new Date(lastSync);
    return date?.toLocaleDateString() + ' at ' + date?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const integrationConfigs = [
    {
      key: 'googleCalendar',
      name: 'Google Calendar',
      icon: 'Calendar',
      description: 'Sync your volunteer events with Google Calendar for better scheduling',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      features: [
        { key: 'syncEvents', label: 'Sync volunteer events to calendar' },
        { key: 'syncReminders', label: 'Create calendar reminders' }
      ]
    },
    {
      key: 'slack',
      name: 'Slack',
      icon: 'MessageSquare',
      description: 'Get event notifications and updates in your Slack workspace',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      features: [
        { key: 'notifications', label: 'Receive event notifications in Slack' }
      ]
    },
    {
      key: 'notion',
      name: 'Notion',
      icon: 'FileText',
      description: 'Track your volunteer hours and achievements in Notion',
      color: 'text-gray-600',
      bgColor: 'bg-gray-50',
      features: [
        { key: 'syncVolunteerHours', label: 'Sync volunteer hours to database' },
        { key: 'syncAchievements', label: 'Track badges and achievements' }
      ]
    }
  ];

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-card-foreground">Integrations</h2>
        <p className="text-sm text-text-secondary mt-1">
          Connect your favorite tools to streamline your volunteer experience
        </p>
      </div>
      <div className="space-y-6">
        {integrationConfigs?.map(config => {
          const integration = integrations?.[config?.key];
          const isConnected = integration?.connected;

          return (
            <div key={config?.key} className="border border-border rounded-lg p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 ${config?.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon name={config?.icon} size={24} className={config?.color} />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-card-foreground">{config?.name}</h3>
                    <p className="text-sm text-text-secondary mt-1">{config?.description}</p>
                    {isConnected && (
                      <div className="flex items-center space-x-2 mt-2">
                        <div className="w-2 h-2 bg-success rounded-full"></div>
                        <span className="text-sm text-success font-medium">Connected</span>
                        {integration?.email && (
                          <span className="text-sm text-text-secondary">• {integration?.email}</span>
                        )}
                        {integration?.workspace && (
                          <span className="text-sm text-text-secondary">• {integration?.workspace}</span>
                        )}
                        {integration?.database && (
                          <span className="text-sm text-text-secondary">• {integration?.database}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2">
                  {isConnected ? (
                    <Button
                      variant="outline"
                      onClick={() => handleDisconnect(config?.key)}
                      iconName="Unlink"
                      iconPosition="left"
                    >
                      Disconnect
                    </Button>
                  ) : (
                    <Button
                      variant="default"
                      onClick={() => handleConnect(config?.key)}
                      iconName="Link"
                      iconPosition="left"
                    >
                      Connect
                    </Button>
                  )}
                </div>
              </div>
              {isConnected && (
                <div className="space-y-4">
                  {/* Integration Settings */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-card-foreground">Settings</h4>
                    {config?.features?.map(feature => (
                      <label key={feature?.key} className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={integration?.[feature?.key]}
                          onChange={() => handleSettingToggle(config?.key, feature?.key)}
                          className="w-4 h-4 text-primary border-border rounded focus:ring-ring focus:ring-2"
                        />
                        <span className="text-sm text-card-foreground">{feature?.label}</span>
                      </label>
                    ))}
                  </div>

                  {/* Last Sync Info */}
                  <div className="pt-3 border-t border-border">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-text-secondary">Last synchronized:</span>
                      <span className="text-card-foreground">{formatLastSync(integration?.lastSync)}</span>
                    </div>
                  </div>
                </div>
              )}
              {!isConnected && (
                <div className="mt-4 p-3 bg-surface rounded-lg">
                  <div className="flex items-start space-x-2">
                    <Icon name="Info" size={16} className="text-primary mt-0.5" />
                    <div className="text-sm text-text-secondary">
                      <p className="font-medium text-card-foreground mb-1">Benefits of connecting {config?.name}:</p>
                      <ul className="space-y-1">
                        {config?.features?.map(feature => (
                          <li key={feature?.key}>• {feature?.label}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {/* Integration Status Summary */}
      <div className="mt-6 p-4 bg-surface rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Zap" size={20} className="text-accent" />
            <span className="font-medium text-card-foreground">Integration Status</span>
          </div>
          <div className="text-sm text-text-secondary">
            {Object.values(integrations)?.filter(i => i?.connected)?.length} of {integrationConfigs?.length} connected
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntegrationsSection;