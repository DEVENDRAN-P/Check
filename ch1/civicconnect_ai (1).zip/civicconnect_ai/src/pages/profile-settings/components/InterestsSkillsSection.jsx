import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const InterestsSkillsSection = ({ userProfile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState(userProfile?.interests || []);
  const [selectedSkills, setSelectedSkills] = useState(userProfile?.skills || []);
  const [selectedCauses, setSelectedCauses] = useState(userProfile?.causes || []);

  const interestOptions = [
    { id: 'environment', label: 'Environmental Protection', icon: 'Leaf' },
    { id: 'education', label: 'Education & Literacy', icon: 'BookOpen' },
    { id: 'healthcare', label: 'Healthcare & Wellness', icon: 'Heart' },
    { id: 'poverty', label: 'Poverty Alleviation', icon: 'HandHeart' },
    { id: 'seniors', label: 'Senior Care', icon: 'Users' },
    { id: 'youth', label: 'Youth Development', icon: 'Baby' },
    { id: 'animals', label: 'Animal Welfare', icon: 'Dog' },
    { id: 'arts', label: 'Arts & Culture', icon: 'Palette' },
    { id: 'technology', label: 'Digital Literacy', icon: 'Laptop' },
    { id: 'disaster', label: 'Disaster Relief', icon: 'Shield' },
    { id: 'housing', label: 'Housing & Homelessness', icon: 'Home' },
    { id: 'food', label: 'Food Security', icon: 'Apple' }
  ];

  const skillOptions = [
    { id: 'leadership', label: 'Leadership & Management', icon: 'Crown' },
    { id: 'communication', label: 'Public Speaking', icon: 'Mic' },
    { id: 'writing', label: 'Writing & Content', icon: 'PenTool' },
    { id: 'design', label: 'Graphic Design', icon: 'Paintbrush' },
    { id: 'web', label: 'Web Development', icon: 'Code' },
    { id: 'marketing', label: 'Marketing & Outreach', icon: 'Megaphone' },
    { id: 'fundraising', label: 'Fundraising', icon: 'DollarSign' },
    { id: 'event', label: 'Event Planning', icon: 'Calendar' },
    { id: 'teaching', label: 'Teaching & Training', icon: 'GraduationCap' },
    { id: 'counseling', label: 'Counseling & Support', icon: 'MessageCircle' },
    { id: 'legal', label: 'Legal Assistance', icon: 'Scale' },
    { id: 'medical', label: 'Medical & Healthcare', icon: 'Stethoscope' }
  ];

  const causeOptions = [
    { id: 'climate', label: 'Climate Change', icon: 'Globe' },
    { id: 'equality', label: 'Social Equality', icon: 'Users' },
    { id: 'democracy', label: 'Democratic Participation', icon: 'Vote' },
    { id: 'transparency', label: 'Government Transparency', icon: 'Eye' },
    { id: 'justice', label: 'Criminal Justice Reform', icon: 'Scale' },
    { id: 'immigration', label: 'Immigration Rights', icon: 'Plane' },
    { id: 'veterans', label: 'Veteran Support', icon: 'Medal' },
    { id: 'disability', label: 'Disability Rights', icon: 'Accessibility' }
  ];

  const toggleSelection = (item, selectedList, setSelectedList) => {
    if (selectedList?.includes(item)) {
      setSelectedList(selectedList?.filter(i => i !== item));
    } else {
      setSelectedList([...selectedList, item]);
    }
  };

  const handleSave = () => {
    onUpdateProfile({
      interests: selectedInterests,
      skills: selectedSkills,
      causes: selectedCauses
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setSelectedInterests(userProfile?.interests || []);
    setSelectedSkills(userProfile?.skills || []);
    setSelectedCauses(userProfile?.causes || []);
    setIsEditing(false);
  };

  const renderSelectionGrid = (options, selectedList, setSelectedList, title) => (
    <div className="space-y-3">
      <h4 className="font-medium text-card-foreground">{title}</h4>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {options?.map((option) => {
          const isSelected = selectedList?.includes(option?.id);
          return (
            <button
              key={option?.id}
              onClick={() => isEditing && toggleSelection(option?.id, selectedList, setSelectedList)}
              disabled={!isEditing}
              className={`flex items-center space-x-2 p-3 rounded-lg border transition-smooth text-left ${
                isSelected
                  ? 'bg-primary/10 border-primary text-primary' :'bg-surface border-border text-text-secondary hover:bg-muted'
              } ${!isEditing ? 'cursor-default' : 'cursor-pointer hover:scale-105'}`}
            >
              <Icon name={option?.icon} size={16} />
              <span className="text-sm font-medium">{option?.label}</span>
              {isSelected && (
                <Icon name="Check" size={14} className="ml-auto text-primary" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-card-foreground">Interests & Skills</h2>
          <p className="text-sm text-text-secondary mt-1">
            Help us recommend relevant events and volunteer opportunities
          </p>
        </div>
        {!isEditing ? (
          <Button variant="outline" onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
            Edit
          </Button>
        ) : (
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button variant="default" onClick={handleSave}>
              Save Changes
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8">
        {renderSelectionGrid(interestOptions, selectedInterests, setSelectedInterests, 'Volunteer Interests')}
        {renderSelectionGrid(skillOptions, selectedSkills, setSelectedSkills, 'Skills & Expertise')}
        {renderSelectionGrid(causeOptions, selectedCauses, setSelectedCauses, 'Causes You Care About')}
      </div>
      {!isEditing && (
        <div className="mt-6 p-4 bg-surface rounded-lg">
          <div className="flex items-start space-x-3">
            <Icon name="Lightbulb" size={20} className="text-accent mt-0.5" />
            <div>
              <h4 className="font-medium text-card-foreground">AI Recommendations</h4>
              <p className="text-sm text-text-secondary mt-1">
                Based on your selections, our AI will suggest events matching your interests: 
                <strong className="text-primary"> {selectedInterests?.length + selectedSkills?.length + selectedCauses?.length} preferences selected</strong>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InterestsSkillsSection;