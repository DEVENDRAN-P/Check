import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';


const PrivacyGamificationSection = ({ userProfile, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [privacySettings, setPrivacySettings] = useState(userProfile?.privacySettings || {
    profileVisibility: 'community', // public, community, private
    showVolunteerHours: true,
    showBadges: true,
    showLocation: false,
    allowDirectMessages: true,
    shareDataForResearch: false,
    includeInLeaderboard: true,
    showInDirectory: true
  });

  const [gamificationSettings, setGamificationSettings] = useState(userProfile?.gamificationSettings || {
    participateInLeaderboard: true,
    showBadgesOnProfile: true,
    receiveAchievementNotifications: true,
    shareAchievements: true,
    competitiveMode: false
  });

  const mockBadges = [
    {
      id: 1,
      name: 'Community Champion',
      description: 'Volunteered for 10+ events',
      icon: 'Award',
      earned: true,
      earnedDate: '2024-08-15',
      color: 'text-yellow-500'
    },
    {
      id: 2,
      name: 'Environmental Warrior',
      description: 'Participated in 5 environmental events',
      icon: 'Leaf',
      earned: true,
      earnedDate: '2024-07-22',
      color: 'text-green-500'
    },
    {
      id: 3,
      name: 'Team Player',
      description: 'Collaborated in 3 team events',
      icon: 'Users',
      earned: true,
      earnedDate: '2024-06-10',
      color: 'text-blue-500'
    },
    {
      id: 4,
      name: 'Event Organizer',
      description: 'Successfully organized an event',
      icon: 'Calendar',
      earned: false,
      color: 'text-gray-400'
    },
    {
      id: 5,
      name: 'Mentor',
      description: 'Mentored 5+ new volunteers',
      icon: 'GraduationCap',
      earned: false,
      color: 'text-gray-400'
    },
    {
      id: 6,
      name: 'Consistency King',
      description: 'Volunteered every month for 6 months',
      icon: 'Target',
      earned: false,
      color: 'text-gray-400'
    }
  ];

  const mockStats = {
    totalHours: 47,
    eventsAttended: 12,
    badgesEarned: 3,
    leaderboardRank: 23,
    impactScore: 850,
    streakDays: 15
  };

  const visibilityOptions = [
    { value: 'public', label: 'Public', description: 'Visible to everyone on the internet' },
    { value: 'community', label: 'Community Only', description: 'Visible to CivicConnect members only' },
    { value: 'private', label: 'Private', description: 'Only visible to you' }
  ];

  const handlePrivacyChange = (setting, value) => {
    setPrivacySettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  const handleGamificationChange = (setting, value) => {
    setGamificationSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  const handleSave = () => {
    onUpdateProfile({
      privacySettings,
      gamificationSettings
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setPrivacySettings(userProfile?.privacySettings || {
      profileVisibility: 'community',
      showVolunteerHours: true,
      showBadges: true,
      showLocation: false,
      allowDirectMessages: true,
      shareDataForResearch: false,
      includeInLeaderboard: true,
      showInDirectory: true
    });
    setGamificationSettings(userProfile?.gamificationSettings || {
      participateInLeaderboard: true,
      showBadgesOnProfile: true,
      receiveAchievementNotifications: true,
      shareAchievements: true,
      competitiveMode: false
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      {/* Privacy Settings */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-card-foreground">Privacy Settings</h2>
            <p className="text-sm text-text-secondary mt-1">
              Control who can see your profile and activity
            </p>
          </div>
          {!isEditing ? (
            <Button variant="outline" onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
              Edit
            </Button>
          ) : (
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
              <Button variant="default" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          )}
        </div>

        <div className="space-y-6">
          {/* Profile Visibility */}
          <div className="space-y-3">
            <h3 className="font-medium text-card-foreground flex items-center">
              <Icon name="Eye" size={18} className="mr-2" />
              Profile Visibility
            </h3>
            <div className="space-y-2">
              {visibilityOptions?.map(option => (
                <label key={option?.value} className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="profileVisibility"
                    value={option?.value}
                    checked={privacySettings?.profileVisibility === option?.value}
                    onChange={(e) => isEditing && handlePrivacyChange('profileVisibility', e?.target?.value)}
                    disabled={!isEditing}
                    className="mt-1 w-4 h-4 text-primary border-border focus:ring-ring focus:ring-2"
                  />
                  <div>
                    <span className="text-sm font-medium text-card-foreground">{option?.label}</span>
                    <p className="text-xs text-text-secondary">{option?.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Privacy Controls */}
          <div className="space-y-4">
            <h3 className="font-medium text-card-foreground flex items-center">
              <Icon name="Shield" size={18} className="mr-2" />
              Privacy Controls
            </h3>
            <div className="space-y-3">
              <Checkbox
                label="Show volunteer hours on profile"
                description="Display your total volunteer hours to other users"
                checked={privacySettings?.showVolunteerHours}
                onChange={(e) => isEditing && handlePrivacyChange('showVolunteerHours', e?.target?.checked)}
                disabled={!isEditing}
              />
              <Checkbox
                label="Show badges and achievements"
                description="Display your earned badges on your public profile"
                checked={privacySettings?.showBadges}
                onChange={(e) => isEditing && handlePrivacyChange('showBadges', e?.target?.checked)}
                disabled={!isEditing}
              />
              <Checkbox
                label="Show approximate location"
                description="Display your city/state to help with local event matching"
                checked={privacySettings?.showLocation}
                onChange={(e) => isEditing && handlePrivacyChange('showLocation', e?.target?.checked)}
                disabled={!isEditing}
              />
              <Checkbox
                label="Allow direct messages"
                description="Let other community members send you messages"
                checked={privacySettings?.allowDirectMessages}
                onChange={(e) => isEditing && handlePrivacyChange('allowDirectMessages', e?.target?.checked)}
                disabled={!isEditing}
              />
              <Checkbox
                label="Include in community directory"
                description="Appear in searchable member directory"
                checked={privacySettings?.showInDirectory}
                onChange={(e) => isEditing && handlePrivacyChange('showInDirectory', e?.target?.checked)}
                disabled={!isEditing}
              />
              <Checkbox
                label="Share anonymized data for research"
                description="Help improve community engagement through research"
                checked={privacySettings?.shareDataForResearch}
                onChange={(e) => isEditing && handlePrivacyChange('shareDataForResearch', e?.target?.checked)}
                disabled={!isEditing}
              />
            </div>
          </div>
        </div>
      </div>
      {/* Gamification Section */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-card-foreground">Achievements & Gamification</h2>
          <p className="text-sm text-text-secondary mt-1">
            Track your progress and celebrate your community impact
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-primary">{mockStats?.totalHours}</div>
            <div className="text-xs text-text-secondary">Hours Volunteered</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-success">{mockStats?.eventsAttended}</div>
            <div className="text-xs text-text-secondary">Events Attended</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-accent">{mockStats?.badgesEarned}</div>
            <div className="text-xs text-text-secondary">Badges Earned</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-secondary">#{mockStats?.leaderboardRank}</div>
            <div className="text-xs text-text-secondary">Leaderboard Rank</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-primary">{mockStats?.impactScore}</div>
            <div className="text-xs text-text-secondary">Impact Score</div>
          </div>
          <div className="text-center p-3 bg-surface rounded-lg">
            <div className="text-2xl font-bold text-success">{mockStats?.streakDays}</div>
            <div className="text-xs text-text-secondary">Day Streak</div>
          </div>
        </div>

        {/* Badges */}
        <div className="mb-8">
          <h3 className="font-medium text-card-foreground mb-4 flex items-center">
            <Icon name="Award" size={18} className="mr-2" />
            Your Badges
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {mockBadges?.map(badge => (
              <div
                key={badge?.id}
                className={`p-4 rounded-lg border transition-smooth ${
                  badge?.earned
                    ? 'bg-card border-border shadow-soft'
                    : 'bg-surface border-border opacity-60'
                }`}
              >
                <div className="flex items-center space-x-3 mb-2">
                  <Icon name={badge?.icon} size={24} className={badge?.color} />
                  <div>
                    <h4 className={`font-medium ${badge?.earned ? 'text-card-foreground' : 'text-text-secondary'}`}>
                      {badge?.name}
                    </h4>
                    {badge?.earned && badge?.earnedDate && (
                      <p className="text-xs text-text-secondary">
                        Earned {new Date(badge.earnedDate)?.toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
                <p className={`text-sm ${badge?.earned ? 'text-text-secondary' : 'text-text-secondary'}`}>
                  {badge?.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Gamification Settings */}
        <div className="space-y-4">
          <h3 className="font-medium text-card-foreground flex items-center">
            <Icon name="Settings" size={18} className="mr-2" />
            Gamification Preferences
          </h3>
          <div className="space-y-3">
            <Checkbox
              label="Participate in community leaderboard"
              description="Show your ranking compared to other volunteers"
              checked={gamificationSettings?.participateInLeaderboard}
              onChange={(e) => isEditing && handleGamificationChange('participateInLeaderboard', e?.target?.checked)}
              disabled={!isEditing}
            />
            <Checkbox
              label="Show badges on profile"
              description="Display earned badges on your public profile"
              checked={gamificationSettings?.showBadgesOnProfile}
              onChange={(e) => isEditing && handleGamificationChange('showBadgesOnProfile', e?.target?.checked)}
              disabled={!isEditing}
            />
            <Checkbox
              label="Receive achievement notifications"
              description="Get notified when you earn new badges or milestones"
              checked={gamificationSettings?.receiveAchievementNotifications}
              onChange={(e) => isEditing && handleGamificationChange('receiveAchievementNotifications', e?.target?.checked)}
              disabled={!isEditing}
            />
            <Checkbox
              label="Share achievements on social media"
              description="Allow automatic sharing of major achievements"
              checked={gamificationSettings?.shareAchievements}
              onChange={(e) => isEditing && handleGamificationChange('shareAchievements', e?.target?.checked)}
              disabled={!isEditing}
            />
            <Checkbox
              label="Enable competitive mode"
              description="Receive challenges and compete with friends"
              checked={gamificationSettings?.competitiveMode}
              onChange={(e) => isEditing && handleGamificationChange('competitiveMode', e?.target?.checked)}
              disabled={!isEditing}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyGamificationSection;