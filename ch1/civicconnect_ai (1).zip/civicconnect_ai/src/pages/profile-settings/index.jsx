import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import AIChatWidget from '../../components/ui/AIChatWidget';
import PersonalInfoSection from './components/PersonalInfoSection';
import InterestsSkillsSection from './components/InterestsSkillsSection';
import LocationAvailabilitySection from './components/LocationAvailabilitySection';
import NotificationPreferencesSection from './components/NotificationPreferencesSection';
import IntegrationsSection from './components/IntegrationsSection';
import PrivacyGamificationSection from './components/PrivacyGamificationSection';
import Icon from '../../components/AppIcon';

const ProfileSettings = () => {
  const [userProfile, setUserProfile] = useState({
    // Personal Information
    name: 'John Doe',
    email: 'john.doe@email.com',
    phone: '+1 (555) 123-4567',
    bio: `Passionate community advocate with over 3 years of volunteer experience. I believe in the power of collective action to create positive change in our neighborhoods. 

My background in environmental science drives my commitment to sustainability initiatives, while my experience in education has taught me the importance of mentoring and knowledge sharing.

I'm always looking for opportunities to contribute to causes that matter and connect with like-minded individuals who share a vision for a better community.`,
    profilePhoto: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face',
    
    // Interests and Skills
    interests: ['environment', 'education', 'youth', 'technology'],
    skills: ['leadership', 'teaching', 'web', 'event'],
    causes: ['climate', 'equality', 'democracy'],
    
    // Location and Availability
    address: '123 Main Street',city: 'San Francisco',state: 'California',zipCode: '94102',
    radius: 15,
    showExactLocation: false,
    showInDirectory: true,
    availability: {
      monday: { morning: false, afternoon: true, evening: false },
      tuesday: { morning: false, afternoon: false, evening: true },
      wednesday: { morning: true, afternoon: true, evening: false },
      thursday: { morning: false, afternoon: true, evening: true },
      friday: { morning: false, afternoon: false, evening: false },
      saturday: { morning: true, afternoon: true, evening: true },
      sunday: { morning: true, afternoon: false, evening: false }
    },
    
    // Notification Preferences
    notificationPreferences: {
      email: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: false,
        weeklyDigest: true,
        newEvents: true,
        eventChanges: true,
        achievements: true
      },
      push: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: false,
        newEvents: false,
        eventChanges: true,
        achievements: true
      },
      inApp: {
        eventRecommendations: true,
        rsvpConfirmations: true,
        eventReminders: true,
        communityUpdates: true,
        newEvents: true,
        eventChanges: true,
        achievements: true
      }
    },
    
    // Integrations
    integrations: {
      googleCalendar: {
        connected: true,
        email: 'john.doe@gmail.com',syncEvents: true,syncReminders: true,lastSync: '2024-09-08T10:30:00Z'
      },
      slack: {
        connected: false,
        workspace: '',channel: '',
        notifications: true,
        lastSync: null
      },
      notion: {
        connected: true,
        database: 'Volunteer Tracker',syncVolunteerHours: true,syncAchievements: false,lastSync: '2024-09-07T15:45:00Z'
      }
    },
    
    // Privacy Settings
    privacySettings: {
      profileVisibility: 'community',
      showVolunteerHours: true,
      showBadges: true,
      showLocation: false,
      allowDirectMessages: true,
      shareDataForResearch: false,
      includeInLeaderboard: true,
      showInDirectory: true
    },
    
    // Gamification Settings
    gamificationSettings: {
      participateInLeaderboard: true,
      showBadgesOnProfile: true,
      receiveAchievementNotifications: true,
      shareAchievements: true,
      competitiveMode: false
    }
  });

  const [activeSection, setActiveSection] = useState('personal');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const sections = [
    { id: 'personal', label: 'Personal Info', icon: 'User' },
    { id: 'interests', label: 'Interests & Skills', icon: 'Heart' },
    { id: 'location', label: 'Location & Availability', icon: 'MapPin' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' },
    { id: 'integrations', label: 'Integrations', icon: 'Link' },
    { id: 'privacy', label: 'Privacy & Achievements', icon: 'Shield' }
  ];

  useEffect(() => {
    // Check for unsaved changes warning
    const handleBeforeUnload = (e) => {
      if (hasUnsavedChanges) {
        e?.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const handleUpdateProfile = (updates) => {
    setUserProfile(prev => ({
      ...prev,
      ...updates
    }));
    setHasUnsavedChanges(false);
    
    // Show success message (in a real app, this would be a toast notification)
    console.log('Profile updated successfully:', updates);
  };

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'personal':
        return (
          <PersonalInfoSection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'interests':
        return (
          <InterestsSkillsSection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'location':
        return (
          <LocationAvailabilitySection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'notifications':
        return (
          <NotificationPreferencesSection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'integrations':
        return (
          <IntegrationsSection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      case 'privacy':
        return (
          <PrivacyGamificationSection
            userProfile={userProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Profile Settings - CivicConnect AI</title>
        <meta name="description" content="Manage your profile settings, preferences, and integrations on CivicConnect AI" />
      </Helmet>
      <Header />
      <div className="pt-16 pb-20 md:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-8">
            {/* Page Header */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-foreground">Profile Settings</h1>
              <p className="text-text-secondary mt-2">
                Manage your personal information, preferences, and community engagement settings
              </p>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
              {/* Sidebar Navigation */}
              <div className="lg:w-64 flex-shrink-0">
                <div className="bg-card rounded-lg border border-border p-4 sticky top-24">
                  <nav className="space-y-2">
                    {sections?.map((section) => (
                      <button
                        key={section?.id}
                        onClick={() => setActiveSection(section?.id)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-smooth text-left ${
                          activeSection === section?.id
                            ? 'bg-primary text-primary-foreground'
                            : 'text-text-secondary hover:text-foreground hover:bg-muted'
                        }`}
                      >
                        <Icon name={section?.icon} size={18} />
                        <span>{section?.label}</span>
                      </button>
                    ))}
                  </nav>

                  {/* Profile Summary */}
                  <div className="mt-6 pt-6 border-t border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                        <Icon name="User" size={20} color="white" />
                      </div>
                      <div>
                        <p className="font-medium text-card-foreground">{userProfile?.name}</p>
                        <p className="text-xs text-text-secondary">
                          {userProfile?.interests?.length + userProfile?.skills?.length} preferences set
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main Content */}
              <div className="flex-1">
                {renderActiveSection()}
              </div>
            </div>
          </div>
        </div>
      </div>
      <AIChatWidget />
    </div>
  );
};

export default ProfileSettings;