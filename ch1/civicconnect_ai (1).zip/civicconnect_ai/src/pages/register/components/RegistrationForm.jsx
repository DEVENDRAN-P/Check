import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const RegistrationForm = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    location: '',
    interests: [],
    skills: [],
    availability: [],
    agreeToTerms: false,
    agreeToPrivacy: false
  });

  const [errors, setErrors] = useState({});
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [showCommunityPrefs, setShowCommunityPrefs] = useState(false);

  const interestOptions = [
    'Environmental Conservation',
    'Education & Literacy',
    'Community Health',
    'Social Justice',
    'Youth Development',
    'Senior Care',
    'Animal Welfare',
    'Arts & Culture',
    'Technology for Good',
    'Disaster Relief'
  ];

  const skillOptions = [
    'Event Planning',
    'Public Speaking',
    'Social Media',
    'Graphic Design',
    'Writing & Communication',
    'Project Management',
    'Teaching & Training',
    'Data Analysis',
    'Fundraising',
    'Photography'
  ];

  const availabilityOptions = [
    'Weekday Mornings',
    'Weekday Evenings',
    'Weekend Mornings',
    'Weekend Evenings',
    'Flexible Schedule'
  ];

  const calculatePasswordStrength = (password) => {
    let strength = 0;
    if (password?.length >= 8) strength += 25;
    if (/[A-Z]/?.test(password)) strength += 25;
    if (/[0-9]/?.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/?.test(password)) strength += 25;
    return strength;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    if (field === 'password') {
      setPasswordStrength(calculatePasswordStrength(value));
    }
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleCheckboxGroupChange = (field, value, checked) => {
    setFormData(prev => ({
      ...prev,
      [field]: checked 
        ? [...prev?.[field], value]
        : prev?.[field]?.filter(item => item !== value)
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.fullName?.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData?.email?.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/?.test(formData?.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData?.password) {
      newErrors.password = 'Password is required';
    } else if (formData?.password?.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    if (formData?.password !== formData?.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData?.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms of service';
    }

    if (!formData?.agreeToPrivacy) {
      newErrors.agreeToPrivacy = 'You must agree to the privacy policy';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 25) return 'bg-destructive';
    if (passwordStrength < 50) return 'bg-warning';
    if (passwordStrength < 75) return 'bg-accent';
    return 'bg-success';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength < 25) return 'Weak';
    if (passwordStrength < 50) return 'Fair';
    if (passwordStrength < 75) return 'Good';
    return 'Strong';
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Basic Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-foreground">Basic Information</h3>
        
        <Input
          label="Full Name"
          type="text"
          placeholder="Enter your full name"
          value={formData?.fullName}
          onChange={(e) => handleInputChange('fullName', e?.target?.value)}
          error={errors?.fullName}
          required
        />

        <Input
          label="Email Address"
          type="email"
          placeholder="Enter your email address"
          value={formData?.email}
          onChange={(e) => handleInputChange('email', e?.target?.value)}
          error={errors?.email}
          required
        />

        <div className="space-y-2">
          <Input
            label="Password"
            type="password"
            placeholder="Create a strong password"
            value={formData?.password}
            onChange={(e) => handleInputChange('password', e?.target?.value)}
            error={errors?.password}
            required
          />
          
          {formData?.password && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-text-secondary">Password strength:</span>
                <span className={`font-medium ${
                  passwordStrength < 25 ? 'text-destructive' :
                  passwordStrength < 50 ? 'text-warning' :
                  passwordStrength < 75 ? 'text-accent' : 'text-success'
                }`}>
                  {getPasswordStrengthText()}
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all ${getPasswordStrengthColor()}`}
                  style={{ width: `${passwordStrength}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <Input
          label="Confirm Password"
          type="password"
          placeholder="Confirm your password"
          value={formData?.confirmPassword}
          onChange={(e) => handleInputChange('confirmPassword', e?.target?.value)}
          error={errors?.confirmPassword}
          required
        />

        <Input
          label="Location"
          type="text"
          placeholder="City, State (for local event recommendations)"
          value={formData?.location}
          onChange={(e) => handleInputChange('location', e?.target?.value)}
          description="Help us recommend events in your area"
        />
      </div>
      {/* Community Preferences */}
      <div className="space-y-4">
        <button
          type="button"
          onClick={() => setShowCommunityPrefs(!showCommunityPrefs)}
          className="flex items-center justify-between w-full p-4 bg-surface rounded-lg hover:bg-muted transition-smooth"
        >
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={20} className="text-primary" />
            <span className="font-medium text-foreground">Community Preferences</span>
            <span className="text-sm text-text-secondary">(Optional)</span>
          </div>
          <Icon 
            name={showCommunityPrefs ? 'ChevronUp' : 'ChevronDown'} 
            size={20} 
            className="text-text-secondary" 
          />
        </button>

        {showCommunityPrefs && (
          <div className="space-y-6 p-4 bg-surface rounded-lg">
            {/* Interests */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Areas of Interest
              </label>
              <p className="text-sm text-text-secondary">
                Select the causes you're passionate about
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {interestOptions?.map((interest) => (
                  <Checkbox
                    key={interest}
                    label={interest}
                    checked={formData?.interests?.includes(interest)}
                    onChange={(e) => handleCheckboxGroupChange('interests', interest, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>

            {/* Skills */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Skills & Expertise
              </label>
              <p className="text-sm text-text-secondary">
                What skills can you contribute to the community?
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {skillOptions?.map((skill) => (
                  <Checkbox
                    key={skill}
                    label={skill}
                    checked={formData?.skills?.includes(skill)}
                    onChange={(e) => handleCheckboxGroupChange('skills', skill, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>

            {/* Availability */}
            <div className="space-y-3">
              <label className="block text-sm font-medium text-foreground">
                Availability
              </label>
              <p className="text-sm text-text-secondary">
                When are you typically available to volunteer?
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {availabilityOptions?.map((availability) => (
                  <Checkbox
                    key={availability}
                    label={availability}
                    checked={formData?.availability?.includes(availability)}
                    onChange={(e) => handleCheckboxGroupChange('availability', availability, e?.target?.checked)}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Terms and Privacy */}
      <div className="space-y-4">
        <Checkbox
          label="I agree to the Terms of Service"
          checked={formData?.agreeToTerms}
          onChange={(e) => handleInputChange('agreeToTerms', e?.target?.checked)}
          error={errors?.agreeToTerms}
          required
        />

        <Checkbox
          label="I agree to the Privacy Policy"
          checked={formData?.agreeToPrivacy}
          onChange={(e) => handleInputChange('agreeToPrivacy', e?.target?.checked)}
          error={errors?.agreeToPrivacy}
          required
        />
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isLoading}
        iconName="UserPlus"
        iconPosition="left"
      >
        Create Account
      </Button>
    </form>
  );
};

export default RegistrationForm;