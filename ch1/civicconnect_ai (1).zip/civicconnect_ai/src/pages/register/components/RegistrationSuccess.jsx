import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RegistrationSuccess = ({ email, onContinue, onResendEmail }) => {
  return (
    <div className="text-center space-y-6">
      {/* Success Icon */}
      <div className="flex justify-center">
        <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center">
          <Icon name="CheckCircle" size={32} className="text-success" />
        </div>
      </div>

      {/* Success Message */}
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-foreground">Account Created Successfully!</h2>
        <p className="text-text-secondary max-w-md mx-auto">
          We've sent a verification email to <strong>{email}</strong>. 
          Please check your inbox and click the verification link to activate your account.
        </p>
      </div>

      {/* Next Steps */}
      <div className="bg-surface rounded-lg p-6 space-y-4">
        <h3 className="font-medium text-foreground">What's Next?</h3>
        <div className="space-y-3 text-sm text-text-secondary">
          <div className="flex items-start space-x-3">
            <Icon name="Mail" size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <span>Check your email for the verification link</span>
          </div>
          <div className="flex items-start space-x-3">
            <Icon name="UserCheck" size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <span>Complete your profile setup</span>
          </div>
          <div className="flex items-start space-x-3">
            <Icon name="Calendar" size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <span>Discover your first volunteer opportunity</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          variant="default"
          fullWidth
          onClick={onContinue}
          iconName="ArrowRight"
          iconPosition="right"
        >
          Continue to Dashboard
        </Button>

        <div className="flex items-center justify-center space-x-2 text-sm">
          <span className="text-text-secondary">Didn't receive the email?</span>
          <Button
            variant="link"
            onClick={onResendEmail}
            className="p-0 h-auto font-medium"
          >
            Resend verification
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RegistrationSuccess;