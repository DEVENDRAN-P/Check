import React from 'react';

import Button from '../../../components/ui/Button';

const SocialRegistration = ({ onGoogleRegister, isLoading }) => {
  const handleGoogleRegister = () => {
    // Mock Google registration
    onGoogleRegister();
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-background text-text-secondary">Or continue with</span>
        </div>
      </div>

      <Button
        variant="outline"
        fullWidth
        onClick={handleGoogleRegister}
        loading={isLoading}
        iconName="Chrome"
        iconPosition="left"
      >
        Continue with Google
      </Button>

      <p className="text-xs text-center text-text-secondary">
        By continuing, you agree to our Terms of Service and Privacy Policy
      </p>
    </div>
  );
};

export default SocialRegistration;