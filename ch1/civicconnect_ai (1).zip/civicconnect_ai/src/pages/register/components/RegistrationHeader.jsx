import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RegistrationHeader = () => {
  const navigate = useNavigate();

  const handleBackToLogin = () => {
    navigate('/login');
  };

  return (
    <div className="text-center space-y-6">
      {/* Logo */}
      <div className="flex justify-center">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
            <Icon name="Users" size={28} color="white" />
          </div>
          <div className="text-left">
            <h1 className="text-2xl font-bold text-foreground">CivicConnect AI</h1>
            <p className="text-sm text-text-secondary">Community Engagement Platform</p>
          </div>
        </div>
      </div>

      {/* Welcome Message */}
      <div className="space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Join Our Community</h2>
        <p className="text-text-secondary max-w-md mx-auto">
          Create your account to discover meaningful volunteer opportunities, 
          connect with like-minded individuals, and make a positive impact in your community.
        </p>
      </div>

      {/* Back to Login */}
      <div className="flex items-center justify-center space-x-2 text-sm">
        <span className="text-text-secondary">Already have an account?</span>
        <Button
          variant="link"
          onClick={handleBackToLogin}
          className="p-0 h-auto font-medium"
        >
          Sign in here
        </Button>
      </div>
    </div>
  );
};

export default RegistrationHeader;