import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RegistrationHeader from './components/RegistrationHeader';
import RegistrationForm from './components/RegistrationForm';
import SocialRegistration from './components/SocialRegistration';
import RegistrationSuccess from './components/RegistrationSuccess';

const Register = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [registrationStep, setRegistrationStep] = useState('form'); // 'form' | 'success'
  const [userEmail, setUserEmail] = useState('');
  const navigate = useNavigate();

  const handleFormSubmit = async (formData) => {
    setIsLoading(true);
    
    try {
      // Mock registration API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      console.log('Registration data:', formData);
      setUserEmail(formData?.email);
      setRegistrationStep('success');
    } catch (error) {
      console.error('Registration failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleRegister = async () => {
    setIsLoading(true);
    
    try {
      // Mock Google registration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      console.log('Google registration successful');
      setUserEmail('user@gmail.com');
      setRegistrationStep('success');
    } catch (error) {
      console.error('Google registration failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleContinueToDashboard = () => {
    navigate('/dashboard');
  };

  const handleResendEmail = async () => {
    try {
      // Mock resend email API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Verification email resent to:', userEmail);
    } catch (error) {
      console.error('Failed to resend email:', error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Main Content */}
      <div className="flex items-center justify-center min-h-screen px-4 py-8">
        <div className="w-full max-w-md space-y-8">
          {registrationStep === 'form' ? (
            <>
              <RegistrationHeader />
              
              <div className="bg-card border border-border rounded-lg shadow-soft p-6 space-y-6">
                <RegistrationForm 
                  onSubmit={handleFormSubmit}
                  isLoading={isLoading}
                />
                
                <SocialRegistration 
                  onGoogleRegister={handleGoogleRegister}
                  isLoading={isLoading}
                />
              </div>
            </>
          ) : (
            <div className="bg-card border border-border rounded-lg shadow-soft p-6">
              <RegistrationSuccess
                email={userEmail}
                onContinue={handleContinueToDashboard}
                onResendEmail={handleResendEmail}
              />
            </div>
          )}
        </div>
      </div>
      {/* Footer */}
      <footer className="bg-surface border-t border-border py-6">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center space-y-2">
            <p className="text-sm text-text-secondary">
              © {new Date()?.getFullYear()} CivicConnect AI. All rights reserved.
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-text-secondary">
              <a href="#" className="hover:text-foreground transition-smooth">Terms of Service</a>
              <span>•</span>
              <a href="#" className="hover:text-foreground transition-smooth">Privacy Policy</a>
              <span>•</span>
              <a href="#" className="hover:text-foreground transition-smooth">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;