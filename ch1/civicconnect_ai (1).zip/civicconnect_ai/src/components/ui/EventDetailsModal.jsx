import React, { useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';
import Image from '../AppImage';

const EventDetailsModal = ({ isOpen, onClose, event }) => {
  useEffect(() => {
    const handleEscape = (e) => {
      if (e?.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !event) return null;

  const handleBackdropClick = (e) => {
    if (e?.target === e?.currentTarget) {
      onClose();
    }
  };

  const handleJoinEvent = () => {
    // Handle join event logic
    console.log('Joining event:', event?.id);
  };

  const handleShareEvent = () => {
    // Handle share event logic
    console.log('Sharing event:', event?.id);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
      onClick={handleBackdropClick}
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-card rounded-lg shadow-elevated overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-semibold text-card-foreground">Event Details</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-140px)]">
          <div className="p-6 space-y-6">
            {/* Event Image */}
            {event?.image && (
              <div className="w-full h-48 rounded-lg overflow-hidden">
                <Image
                  src={event?.image}
                  alt={event?.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Event Title and Basic Info */}
            <div className="space-y-4">
              <h3 className="text-2xl font-semibold text-card-foreground">{event?.title}</h3>
              
              <div className="flex flex-wrap gap-4 text-sm text-text-secondary">
                <div className="flex items-center space-x-2">
                  <Icon name="Calendar" size={16} />
                  <span>{event?.date}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Clock" size={16} />
                  <span>{event?.time}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="MapPin" size={16} />
                  <span>{event?.location}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Icon name="Users" size={16} />
                  <span>{event?.attendees} attending</span>
                </div>
              </div>

              {/* Event Tags */}
              <div className="flex flex-wrap gap-2">
                {event?.tags?.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-accent/10 text-accent text-xs font-medium rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Event Description */}
            <div className="space-y-3">
              <h4 className="text-lg font-medium text-card-foreground">About This Event</h4>
              <p className="text-text-secondary leading-relaxed">{event?.description}</p>
            </div>

            {/* Organizer Info */}
            <div className="space-y-3">
              <h4 className="text-lg font-medium text-card-foreground">Organizer</h4>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                  <Icon name="User" size={20} color="white" />
                </div>
                <div>
                  <p className="font-medium text-card-foreground">{event?.organizer}</p>
                  <p className="text-sm text-text-secondary">{event?.organizerRole}</p>
                </div>
              </div>
            </div>

            {/* Requirements */}
            {event?.requirements && (
              <div className="space-y-3">
                <h4 className="text-lg font-medium text-card-foreground">Requirements</h4>
                <ul className="space-y-2">
                  {event?.requirements?.map((requirement, index) => (
                    <li key={index} className="flex items-start space-x-2 text-text-secondary">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>{requirement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Impact Metrics */}
            {event?.impact && (
              <div className="space-y-3">
                <h4 className="text-lg font-medium text-card-foreground">Expected Impact</h4>
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(event?.impact)?.map(([key, value]) => (
                    <div key={key} className="text-center p-3 bg-surface rounded-lg">
                      <p className="text-2xl font-semibold text-primary">{value}</p>
                      <p className="text-sm text-text-secondary capitalize">{key?.replace('_', ' ')}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-6 border-t border-border bg-surface">
          <Button variant="outline" onClick={handleShareEvent} iconName="Share2" iconPosition="left">
            Share Event
          </Button>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button variant="default" onClick={handleJoinEvent} iconName="UserPlus" iconPosition="left">
              Join Event
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetailsModal;